import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { IconRenderer } from '../components/Icons';
import { Service, Product } from '../types';
import { ServiceSkeleton } from '../components/Skeleton';
import { SEO } from '../components/SEO';
import { CallbackModal } from '../components/CallbackModal';
import { DotLottieReact, setWasmUrl } from '@lottiefiles/dotlottie-react';
import type { DotLottie } from '@lottiefiles/dotlottie-react';
import { secureUrl } from '../utils/secureUrl';

setWasmUrl('/lottie/dotlottie-player.wasm');

interface HomeProps {
  onNavigate: (page: string) => void;
  services: Service[];
  products?: Product[];
  onSelectService: (service: Service) => void;
  loading?: boolean;
}

export function Home({ onNavigate, services, products = [], onSelectService, loading }: HomeProps) {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [isCallbackModalOpen, setIsCallbackModalOpen] = useState(false);
  const [dotLottie, setDotLottie] = useState<DotLottie | null>(null);
  const [isAnimationLoading, setIsAnimationLoading] = useState(true);

  useEffect(() => {
    if (!dotLottie) return;

    const handleAnimationReady = () => setIsAnimationLoading(false);
    dotLottie.addEventListener('load', handleAnimationReady);
    dotLottie.addEventListener('loadError', handleAnimationReady);

    return () => {
      dotLottie.removeEventListener('load', handleAnimationReady);
      dotLottie.removeEventListener('loadError', handleAnimationReady);
    };
  }, [dotLottie]);

  // Show callback modal after 2 seconds on mount
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsCallbackModalOpen(true);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  // Get popular products (in stock, filtered)
  const popularProducts = products
    .filter(p => p.inStock)
    .sort((a, b) => (b.ratings?.count || 0) - (a.ratings?.count || 0))
    .slice(0, 3);

  const filteredServices = services.filter(s => 
    (s.name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (s.description || '').toLowerCase().includes(searchTerm.toLowerCase())
  ).slice(0, 3);

  return (
    <div className="space-y-8 sm:space-y-12">
      <CallbackModal 
        isOpen={isCallbackModalOpen} 
        onClose={() => setIsCallbackModalOpen(false)} 
      />
      
      <SEO 
        title="India Cyber Cafe - Digital Seva Simplified | CSC, Online Services"
        description={`Apply for Government Services, Jobs & Documents online with India's trusted digital partner. ${services.length} services available. Fast, secure, and reliable digital solutions.`}
        keywords="Digital Seva, CSC Services, Online Application, Government Services, Pan Card, Aadhaar, Passport, Cyber Cafe, Digital India"
        ogType="website"
        structuredData={{
          "@context": "https://schema.org",
          "@type": "WebSite",
          "name": "India Cyber Cafe",
          "url": "https://b.indiacybercafe.com",
          "potentialAction": {
            "@type": "SearchAction",
            "target": {
              "@type": "EntryPoint",
              "urlTemplate": "https://b.indiacybercafe.com/services?search={search_term_string}"
            },
            "query-input": "required name=search_term_string"
          }
        }}
      />
      {/* Hero Section */}
      <section className="bg-white p-6 sm:p-10 lg:p-12 rounded-3xl shadow-xl flex flex-col md:flex-row items-center justify-between gap-6 md:gap-10 border border-slate-100">
        <div className="flex-1 space-y-3 sm:space-y-5 text-center md:text-left">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-navy leading-tight">
            India Cyber Cafe <br />
            <span className="text-primary">Digital Seva Simplified</span>
          </h1>
          <p className="text-sm sm:text-base lg:text-lg text-slate-600 max-w-md mx-auto md:mx-0">
            Apply for Government Services, Jobs & Documents online with India's trusted digital partner.
          </p>
          <div className="flex flex-col sm:flex-row flex-wrap gap-3 justify-center md:justify-start pt-2">
            <Link to="/services" className="btn-primary text-sm sm:text-base px-6 sm:px-8 py-2.5 sm:py-3 text-center inline-block">Apply Now</Link>
            <Link to="/track" className="btn-outline text-sm sm:text-base px-6 sm:px-8 py-2.5 sm:py-3 text-center inline-block">Track Status</Link>
          </div>
        </div>
        <div className="hidden md:flex items-center justify-center shrink-0 h-[300px] lg:h-[300px]">
          <div className="relative w-full h-full flex items-center justify-center">
            {isAnimationLoading && (
              <div className="absolute inset-0 flex items-center justify-center" aria-hidden="true">
                <div className="absolute w-32 h-32 lg:w-40 lg:h-40 rounded-full border-2 border-primary/20 animate-pulse"></div>
                <div className="absolute w-24 h-24 lg:w-32 lg:h-32 rounded-full border-2 border-primary/30 animate-spin" style={{animationDuration: '8s'}}></div>
              </div>
            )}
            <DotLottieReact
              src="/hero-animation.lottie"
              style={{ width: '300px', height: '300px' }}
              autoplay
              loop
              dotLottieRefCallback={setDotLottie}
            />
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {[
          { icon: 'users', count: '5000+', label: 'Active Users' },
            { videoUrl: 'https://cdn-icons-mp4.freepik.com/512/18997/18997679.mp4', count: '2500+', label: 'Applications' },
            { videoUrl: 'https://cdn-icons-mp4.freepik.com/512/15370/15370738.mp4', count: '24/7', label: 'Support' },
          { icon: 'star', count: '4.9/5', label: 'Rating' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-4 sm:p-8 rounded-2xl text-center shadow-md border-t-4 border-primary hover:-translate-y-2 active:translate-y-0 active:scale-95 transition-all">
              {stat.videoUrl ? (
                <video
                  src={stat.videoUrl}
                  className="w-6 h-6 sm:w-10 sm:h-10 mx-auto mb-2 sm:mb-4"
                  autoPlay
                  loop
                  muted
                  playsInline
                />
              ) : (
                <IconRenderer name={stat.icon || 'layers'} className="w-6 h-6 sm:w-10 sm:h-10 text-primary mx-auto mb-2 sm:mb-4" />
              )}
            <h3 className="text-xl sm:text-3xl font-bold text-navy mb-1">{stat.count}</h3>
            <p className="text-[10px] sm:text-sm text-slate-500 font-medium uppercase tracking-wider">{stat.label}</p>
          </div>
        ))}
      </section>

      {/* Popular Services Section */}
      <section className="space-y-6 sm:space-y-8">
        <div className="text-center space-y-3 sm:space-y-4">
          <h2 className="text-2xl sm:text-3xl font-bold text-navy">Popular Services</h2>
          <div className="max-w-xl mx-auto relative">
            <IconRenderer name="search" className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search all services..." 
              className="input-field pl-12 py-2.5 sm:py-3"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        {loading && services.length === 0 ? (
          <ServiceSkeleton />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {filteredServices.map(service => (
              <Link 
                key={service.id} 
                to={`/services/${service.id}`}
                className="card group cursor-pointer p-4 sm:p-6 block"
              >
                <div className={`flex items-center justify-center mx-auto mb-3 sm:mb-4 transition-all ${
                  service.iconType === 'url' && service.icon
                    ? 'w-full h-40 sm:h-48 rounded-xl border border-slate-200 overflow-hidden'
                    : 'w-12 h-12 sm:w-16 sm:h-16 bg-linear-to-br from-primary/10 to-navy/10 rounded-full group-hover:rotate-12 overflow-hidden'
                }`}>
                  {service.iconType === 'url' && service.icon ? (
                    (service.icon || '').toLowerCase().endsWith('.mp4') ? (
                      <video src={secureUrl(service.icon)} className="w-full h-full object-cover" muted autoPlay loop />
                    ) : (
                      <img src={secureUrl(service.icon)} alt={service.name || 'Service'} className="w-full h-full object-cover" />
                    )
                  ) : (
                    <IconRenderer name={service.icon || 'layers'} className="w-6 h-6 sm:w-8 sm:h-8 text-navy group-hover:text-primary transition-all" />
                  )}
                </div>
                <h3 className="text-base sm:text-lg font-bold text-navy mb-1">{service.name || 'Service'}</h3>
                <p className="text-slate-500 text-[10px] sm:text-xs line-clamp-2">{service.description || ''}</p>
              </Link>
            ))}
            {filteredServices.length === 0 && searchTerm && (
              <div className="col-span-full p-10 text-center text-slate-400 italic">No services found for "{searchTerm}"</div>
            )}
          </div>
        )}

        <div className="text-center">
          <Link to="/services" className="btn-primary inline-block">View All Services →</Link>
        </div>
      </section>

      {/* Features Section */}
      <section className="space-y-6 sm:space-y-10">
        <h2 className="text-2xl sm:text-3xl font-bold text-navy text-center">Why Choose Us?</h2>
        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6 lg:gap-8">
          {[
            { icon: 'shield-check', title: '100% Secure', desc: 'Encrypted & protected data' },
            { iconUrl: '/icons/bi--rocket-takeoff.svg', title: 'Lightning Fast', desc: 'Instant processing' },
            { icon: 'smartphone', title: 'Mobile Friendly', desc: 'Access anywhere' },
            { iconUrl: '/icons/bx--support.svg', title: 'Expert Support', desc: '24/7 Professional help' },
            { icon: 'check-circle', title: 'Easy Process', desc: 'Simple steps' },
            { icon: 'clock', title: 'Real-time Updates', desc: 'Instant notifications' },
          ].map((feature, i) => (
            <div key={i} className="bg-white p-4 sm:p-6 lg:p-10 rounded-2xl text-center shadow-md border-t-4 border-primary hover:-translate-y-2 active:translate-y-0 active:scale-95 transition-all">
              <div className="w-10 h-10 sm:w-12 sm:h-12 lg:w-16 lg:h-16 bg-linear-to-br from-primary/10 to-navy/10 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4 lg:mb-6">
                {feature.iconUrl ? (
                  <span
                    aria-hidden="true"
                    className="w-5 h-5 sm:w-6 sm:h-6 lg:w-8 lg:h-8 bg-primary"
                    style={{ WebkitMaskImage: `url(${feature.iconUrl})`, maskImage: `url(${feature.iconUrl})`, WebkitMaskRepeat: 'no-repeat', maskRepeat: 'no-repeat', WebkitMaskPosition: 'center', maskPosition: 'center', WebkitMaskSize: 'contain', maskSize: 'contain' }}
                  />
                ) : (
                  <IconRenderer name={feature.icon || 'layers'} className="w-5 h-5 sm:w-6 sm:h-6 lg:w-8 lg:h-8 text-primary" />
                )}
              </div>
              <h3 className="text-sm sm:text-base lg:text-xl font-bold text-navy mb-1 sm:mb-2 lg:mb-3">{feature.title}</h3>
              <p className="text-[10px] sm:text-sm lg:text-base text-slate-600 leading-tight sm:leading-relaxed">{feature.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Popular Products Section */}
      <section className="space-y-6 sm:space-y-8">
        <div className="text-center space-y-3 sm:space-y-4">
          <h2 className="text-2xl sm:text-3xl font-bold text-navy">Popular Products</h2>
          <p className="text-sm sm:text-base text-slate-600">Premium prints & services with custom options</p>
        </div>

        {popularProducts.length > 0 ? (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-5 lg:gap-6">
              {popularProducts.map(product => (
                <Link
                  key={product.id}
                  to={`/store/${product.category}/${product.id}`}
                  className="group cursor-pointer bg-white rounded-xl sm:rounded-2xl overflow-hidden border border-slate-200 hover:border-primary hover:shadow-lg transition-all block"
                >
                  {/* Image Container */}
                  <div className="relative aspect-square overflow-hidden bg-slate-100">
                    <img
                      src={secureUrl(product.images[0])}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    {product.discountedPrice && (
                      <div className="absolute top-2 right-2 bg-red-500 text-white px-2 sm:px-3 py-1 rounded-full text-xs sm:text-sm font-bold">
                        {Math.round(((product.price - product.discountedPrice) / product.price) * 100)}% OFF
                      </div>
                    )}
                  </div>

                  {/* Content */}
                  <div className="p-3 sm:p-4">
                    {/* Name */}
                    <h3 className="text-xs sm:text-sm font-bold text-navy mb-1 sm:mb-2 line-clamp-2 group-hover:text-primary transition-colors">
                      {product.name}
                    </h3>

                    {/* Description */}
                    <p className="text-[9px] sm:text-xs text-slate-500 mb-2 sm:mb-3 line-clamp-1">
                      {product.shortDescription}
                    </p>

                    {/* Rating */}
                    {product.ratings && product.ratings.count > 0 && (
                      <div className="flex items-center gap-1 mb-2 sm:mb-3">
                        <div className="flex text-yellow-400">
                          {[...Array(5)].map((_, i) => (
                            <span key={i} className="text-[10px] sm:text-xs">
                              {i < Math.round(product.ratings!.average) ? '★' : '☆'}
                            </span>
                          ))}
                        </div>
                        <span className="text-[8px] sm:text-[9px] text-slate-500">
                          ({product.ratings.count})
                        </span>
                      </div>
                    )}

                    {/* Price */}
                    <div className="flex items-center gap-2">
                      <span className="text-xs sm:text-sm font-bold text-navy">
                        ₹{product.discountedPrice || product.price}
                      </span>
                      {product.discountedPrice && (
                        <span className="text-[8px] sm:text-[9px] text-slate-400 line-through">
                          ₹{product.price}
                        </span>
                      )}
                    </div>
                  </div>
                </Link>
              ))}
            </div>

            <div className="text-center">
              <Link to="/store" className="btn-primary inline-block">
                Explore Store →
              </Link>
            </div>
          </>
        ) : (
          <div className="bg-white rounded-2xl p-12 sm:p-16 text-center border border-slate-200">
            <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
              </svg>
            </div>
            <h3 className="text-lg sm:text-xl font-bold text-navy mb-2">No Products Available</h3>
            <p className="text-sm text-slate-500 mb-6">Our store is coming soon with amazing products!</p>
            <Link to="/store" className="btn-primary inline-block">
              View Store
            </Link>
          </div>
        )}
      </section>

      {/* How It Works */}
      <section className="space-y-6 sm:space-y-10 bg-navy/5 p-4 sm:p-12 rounded-3xl">
        <h2 className="text-2xl sm:text-3xl font-bold text-navy text-center">How It Works</h2>
        <div className="grid grid-cols-3 sm:grid-cols-3 lg:flex lg:flex-row items-center justify-between gap-4 sm:gap-8">
          {[
            { num: 1, icon: 'user-plus', title: 'Register', desc: 'Account' },
            { num: 2, iconUrl: '/icons/grommet-icons--select.svg', title: 'Select', desc: 'Service' },
            { num: 3, icon: 'user-pen', title: 'Fill', desc: 'Info' },
            { num: 4, icon: 'paper-plane', title: 'Submit', desc: 'Apply' },
            { num: 5, icon: 'eye', title: 'Track', desc: 'Status' },
          ].map((step, i) => (
            <div key={i} className="flex-1 w-full flex flex-col items-center text-center space-y-1 sm:space-y-4 relative">
              <div className="w-6 h-6 sm:w-12 sm:h-12 bg-linear-to-br from-primary to-primary-dark text-white rounded-full flex items-center justify-center font-bold text-xs sm:text-xl shadow-lg z-10">
                {step.num}
              </div>
              {step.iconUrl ? (
                <span
                  aria-hidden="true"
                  className="w-5 h-5 sm:w-10 sm:h-10 bg-primary"
                  style={{ WebkitMaskImage: `url(${step.iconUrl})`, maskImage: `url(${step.iconUrl})`, WebkitMaskRepeat: 'no-repeat', maskRepeat: 'no-repeat', WebkitMaskPosition: 'center', maskPosition: 'center', WebkitMaskSize: 'contain', maskSize: 'contain' }}
                />
              ) : (
                <IconRenderer name={step.icon || 'layers'} className="w-5 h-5 sm:w-10 sm:h-10 text-primary" />
              )}
              <h3 className="font-bold text-navy text-[10px] sm:text-base">{step.title}</h3>
              <p className="text-[8px] sm:text-sm text-slate-500 hidden sm:block">{step.desc}</p>
              {i < 4 && (
                <div className="hidden lg:block absolute top-6 left-[60%] w-[80%] h-1 bg-linear-to-r from-primary to-transparent" />
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Forms & Documents CTA */}
      <section className="rounded-3xl border border-primary/20 bg-white px-6 py-8 shadow-sm sm:px-10 lg:px-14">
        <div className="flex flex-col items-center justify-between gap-6 text-center md:flex-row md:text-left">
          <div className="max-w-3xl">
            <p className="text-xs font-black uppercase tracking-[0.24em] text-primary">Forms & Documents</p>
            <p className="mt-3 text-sm font-medium leading-relaxed text-slate-600 sm:text-base lg:text-lg">
              If you need any forms or documents, visit our Forms & Documents page.
            </p>
          </div>
          <Link to="/forms-documents" className="btn-primary whitespace-nowrap px-7 py-3 text-sm sm:text-base">
            View Forms & Documents
          </Link>
        </div>
      </section>
    </div>
  );
}
