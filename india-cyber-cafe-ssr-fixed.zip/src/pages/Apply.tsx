import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Service, UserProfile, SubService, Application, PaymentGateway } from '../types';
import { IconRenderer } from '../components/Icons';
import { SelectDropdown } from '../components/SelectDropdown';
import { secureUrl } from '../utils/secureUrl';
import { showToast } from '../components/Toast';
import { rtdb } from '../firebase';
import { ref as dbRef, set } from 'firebase/database';
import { sendEmail, sendEmailToAllAdmins, emailTemplates } from '../services/emailService';
import { MAX_SERVICE_FILE_SIZE, uploadFile } from '../services/uploadService';
import { SEO } from '../components/SEO';
import { ShareButton } from '../components/ShareButton';
import { getServiceShareData, getSubServiceShareData } from '../utils/shareUtils';
import { getRazorpayKeyId, loadRazorpayScript, verifyRazorpayPayment } from '../services/razorpayService';
import { sanitizeFormData, sanitizeUserProfile, sanitizeEmail } from '../utils/sanitizer';
import { ApplySkeleton } from '../components/Skeleton';
import { getFriendlyErrorMessage } from '../utils/errorHandler';

interface ApplyProps {
  services: Service[];
  user: UserProfile;
  gateways: PaymentGateway[];
  onSuccess: () => void;
  isLoading?: boolean;
  error?: Error | null;
  onRetry?: () => void;
}

export function Apply({ services, user, gateways, onSuccess, isLoading = false, error = null, onRetry }: ApplyProps) {
  const { serviceId, subserviceName } = useParams<{ serviceId: string; subserviceName: string }>();
  const navigate = useNavigate();
  
  const service = services.find(s => s.id === serviceId);
  const [selectedSubService, setSelectedSubService] = useState<SubService | null>(null);
  const [subServiceNotFound, setSubServiceNotFound] = useState(false);
  const [formData, setFormData] = useState<Record<string, any>>({});
  const [files, setFiles] = useState<Record<string, File[]>>({});
  const [loading, setLoading] = useState(false);
  const [declarationChecked, setDeclarationChecked] = useState(false);
  const [paymentProcessing, setPaymentProcessing] = useState(false);
  const paymentProcessingRef = useRef(false);
  const [uploadProgress, setUploadProgress] = useState<{ current: number; total: number }>({ current: 0, total: 0 });

  useEffect(() => {
    if (!paymentProcessing) return;

    const handleBeforeUnload = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = '';
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [paymentProcessing]);

  const slugify = (text: string) => text.toLowerCase().trim().replace(/[^\w\s-]/g, '').replace(/[\s_-]+/g, '-').replace(/^-+|-+$/g, '');

  useEffect(() => {
    if (service && subserviceName) {
      const sub = service.subservices.find(ss => 
        slugify(ss.name) === subserviceName
      );
      if (sub) {
        setSelectedSubService(sub);
        setSubServiceNotFound(false);
      } else {
        setSubServiceNotFound(true);
      }
    }
  }, [service, subserviceName]);

  if (isLoading) {
    return <ApplySkeleton />;
  }

  if (error) {
    return (
      <div className="text-center py-20">
        <IconRenderer name="alert-circle" className="w-16 h-16 text-red-400 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-slate-600 mb-2">Failed to Load Services</h2>
        <p className="text-slate-500 text-sm mb-6">{getFriendlyErrorMessage(error, 'An error occurred while loading services.')}</p>
        <button onClick={onRetry} className="btn-primary">Retry</button>
      </div>
    );
  }

  if (!service) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold text-navy">Service Not Found</h2>
        <button onClick={() => navigate('/services')} className="btn-primary mt-4">Back to Services</button>
      </div>
    );
  }

  const handleInputChange = (label: string, value: any) => {
    setFormData(prev => ({ ...prev, [label]: value }));
  };

  const isAcceptedFile = (file: File, accept?: string) => {
    if (!accept?.trim()) return true;

    const fileName = file.name.toLowerCase();
    const fileType = file.type.toLowerCase();
    return accept.split(',').some(value => {
      const rule = value.trim().toLowerCase();
      if (!rule) return false;
      if (rule.startsWith('.')) return fileName.endsWith(rule);
      if (rule.endsWith('/*')) return fileType.startsWith(`${rule.slice(0, -1)}`);
      return fileType === rule;
    });
  };

  const handleFileChange = (label: string, selectedFiles: FileList | null, multiple: boolean, accept?: string) => {
    const selected = Array.from(selectedFiles || []);
    const validFiles = selected.filter(file => file.size <= MAX_SERVICE_FILE_SIZE);
    const oversizedFiles = selected.filter(file => file.size > MAX_SERVICE_FILE_SIZE);
    const invalidFiles = validFiles.filter(file => !isAcceptedFile(file, accept));
    const acceptedFiles = validFiles.filter(file => isAcceptedFile(file, accept));
    if (oversizedFiles.length > 0) {
      showToast(`File "${oversizedFiles[0].name}" exceeds the 5 MB limit.`, 'error');
    }
    if (invalidFiles.length > 0) {
      showToast(`File "${invalidFiles[0].name}" is not an accepted file type.`, 'error');
    }

    setFiles(prev => {
      if (multiple) {
        return { ...prev, [label]: [...(prev[label] || []), ...acceptedFiles] };
      }
      return acceptedFiles.length > 0 ? { ...prev, [label]: acceptedFiles.slice(0, 1) } : prev;
    });
  };

  const removeFile = (label: string, fileIndex: number, inputId: string) => {
    setFiles(prev => {
      const remaining = (prev[label] || []).filter((_, index) => index !== fileIndex);
      const next = { ...prev };
      if (remaining.length > 0) next[label] = remaining;
      else delete next[label];
      return next;
    });
    const input = document.getElementById(inputId) as HTMLInputElement | null;
    if (input) input.value = '';
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading || paymentProcessingRef.current) return;
    if (service.subservices.length > 0 && !selectedSubService) {
      showToast('Please select a sub-service', 'error');
      return;
    }

    if (!declarationChecked) {
      showToast('Please accept the privacy notice and declaration before proceeding.', 'error');
      return;
    }

    const oversizedFile = Object.values(files).flat().find(file => file.size > MAX_SERVICE_FILE_SIZE);
    if (oversizedFile) {
      showToast(`File "${oversizedFile.name}" exceeds the 5 MB limit.`, 'error');
      return;
    }

    const activeFields = selectedSubService?.fields && selectedSubService.fields.length > 0
      ? selectedSubService.fields
      : service.fields;
    const missingRequiredMultiselect = activeFields.find(field => (
      field.type === 'multiselect' &&
      field.required !== false &&
      (!Array.isArray(formData[field.name || field.label]) || formData[field.name || field.label].length === 0)
    ));
    if (missingRequiredMultiselect) {
      showToast(`${missingRequiredMultiselect.label} is required.`, 'error');
      return;
    }
    const missingRequiredFile = activeFields.find(field => (
      field.type === 'file' && field.required !== false && !(files[field.label]?.length)
    ));
    if (missingRequiredFile) {
      showToast(`${missingRequiredFile.label} is required.`, 'error');
      return;
    }

    setLoading(true);
    try {
      const uploadedFiles: Record<string, string | string[]> = {};
      
      // Upload files to Firebase Storage
      const fileEntries = Object.entries(files) as [string, File[]][];
      setUploadProgress({ current: 0, total: fileEntries.reduce((total, [, fieldFiles]) => total + fieldFiles.length, 0) });
      
      for (let i = 0; i < fileEntries.length; i++) {
        const [label, fieldFiles] = fileEntries[i];
        const urls: string[] = [];
        for (const file of fieldFiles) {
          urls.push(await uploadFile(file, 'applications', MAX_SERVICE_FILE_SIZE));
          setUploadProgress(prev => ({ current: prev.current + 1, total: prev.total }));
        }
        const activeFields = selectedSubService?.fields && selectedSubService.fields.length > 0
          ? selectedSubService.fields
          : service.fields;
        const field = activeFields.find(activeField => activeField.label === label);
        uploadedFiles[label] = field?.multiple === true ? urls : urls[0];
      }

      // Generate ID: ICC-DDMMYYYY-HHMMSS-RRRR
      const now = new Date();
      const dateStr = now.toLocaleDateString('en-GB').replace(/\//g, ''); // DDMMYYYY
      const timeStr = now.toTimeString().split(' ')[0].replace(/:/g, ''); // HHMMSS
      const randomStr = Math.floor(1000 + Math.random() * 9000).toString(); // 4 random digits
      const appId = `ICC-${dateStr}-${timeStr}-${randomStr}`;

      // Sanitize all form data before saving - convert display labels to valid database keys
      const sanitizedDetails = sanitizeFormData({ ...formData, ...uploadedFiles });
      const sanitizedEmail = sanitizeEmail(user.email);

      const application: any = {
        uid: user.uid,
        email: sanitizedEmail,
        name: user.name.trim(),
        serviceName: service.name.trim(),
        serviceId: service.id,
        details: sanitizedDetails,
        status: 'processing',
        date: now.toISOString(),
        notes: [],
        paymentStatus: (selectedSubService?.paymentMethods?.includes('free') || selectedSubService?.paymentMethods?.includes('cash')) ? 'completed' : 'pending'
      };

      if (selectedSubService) {
        application.subserviceName = selectedSubService.name;
        application.charge = selectedSubService.charge || 0;
      }

      const submitApp = async (appData: any) => {
        const appWithId = { ...appData, id: appId };
        await set(dbRef(rtdb, `applications/${appId}`), appWithId);
        
        // Send Confirmation Email to User
        sendEmail(user.email, 'Application Received - India Cyber Cafe', emailTemplates.applicationSubmitted(user.name, service.name, appId));
        
        // Notify All Admins
        sendEmailToAllAdmins('New Application Received - India Cyber Cafe', emailTemplates.adminNewApplication(user.name, user.email, service.name, appId));
        
        // If payment completed, send payment confirmation
        if (appData.paymentStatus === 'completed' && appData.charge) {
          sendEmail(user.email, 'Payment Confirmed - India Cyber Cafe', emailTemplates.paymentReceived(user.name, appData.charge.toString(), service.name, appId));
          sendEmailToAllAdmins('Payment Received - India Cyber Cafe', emailTemplates.adminPaymentReceived(user.name, appData.charge.toString(), service.name, appId));
        }

        showToast('Application Submitted Successfully!');
        onSuccess();
      };

      if (selectedSubService) {
        const methods = selectedSubService.paymentMethods;
        
        if (methods.includes('razorpay')) {
          // Handle Razorpay - Create order on backend first
          try {
            const charge = selectedSubService.charge || 0;
            const chargeInPaisa = charge * 100;

            console.log('📋 Creating order on backend for service... Amount:', chargeInPaisa, 'Paisa');
            const orderResponse = await fetch('/api/create-razorpay-order', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                amount: chargeInPaisa,
                currency: 'INR',
                receipt: appId,
                notes: {
                  serviceId: service.id,
                  serviceName: service.name,
                  subServiceName: selectedSubService.name
                }
              })
            });

            console.log('📡 Order response status:', orderResponse.status, orderResponse.statusText);

            if (!orderResponse.ok) {
              const errorData = await orderResponse.json().catch(() => ({ error: 'Unknown error' }));
              console.error('❌ Order creation failed:', errorData);
              throw new Error(errorData.error || `Server error: ${orderResponse.status}`);
            }

            const orderData = await orderResponse.json();
            console.log('✅ Order created on backend:', orderData);

            if (!orderData.order_id && !orderData.orderId) {
              throw new Error('No order ID returned from server');
            }

            const razorpayOrderId = orderData.order_id || orderData.orderId;

            const scriptLoaded = await loadRazorpayScript();
            if (!scriptLoaded || !window.Razorpay) {
              console.error('❌ Razorpay window object not found');
              showToast('❌ Payment system not available. Please refresh the page.', 'error');
              setLoading(false);
              return;
            }

            const activeRazorpay = gateways.find(g => g.type === 'razorpay' && g.active);
            const key = orderData.keyId || activeRazorpay?.credentials?.keyId || getRazorpayKeyId();

            const options = {
              key,
              amount: chargeInPaisa,
              currency: 'INR',
              order_id: razorpayOrderId,
              name: 'India Cyber Cafe',
              description: `Payment for ${service.name}`,
              handler: async (response: any) => {
                if (paymentProcessingRef.current) return;
                paymentProcessingRef.current = true;
                setPaymentProcessing(true);

                try {
                  // Verify payment with backend using Razorpay signature
                  const verificationResult = await verifyRazorpayPayment(
                    response.razorpay_payment_id,
                  response.razorpay_order_id,
                  response.razorpay_signature
                );

                if (!verificationResult.verified) {
                  throw new Error(verificationResult.error || 'Payment verification failed');
                }

                // Payment verified, save application
                application.paymentMethod = 'razorpay';
                application.paymentStatus = 'completed';
                application.razorpayPaymentId = response.razorpay_payment_id;
                application.razorpayOrderId = response.razorpay_order_id;
                await submitApp(application);
              } catch (error: any) {
                console.error('Payment verification error:', error);
                paymentProcessingRef.current = false;
                setPaymentProcessing(false);
                showToast(error, 'error', 'Payment could not be verified.');
              }
            },
              prefill: {
                name: user.name,
                email: user.email,
                contact: user.phone || ''
              },
              modal: {
                ondismiss: () => {
                  console.log('⚠️ Payment modal closed by user');
                  paymentProcessingRef.current = false;
                  setPaymentProcessing(false);
                  setLoading(false);
                  showToast('Payment was cancelled. You can try again whenever you\'re ready.', 'info');
                }
              },
              theme: { color: '#FF9933' }
            };

            console.log('🚀 Opening Razorpay checkout for service...');
            const rzp = new (window as any).Razorpay(options);
            rzp.open();
          } catch (error: any) {
            console.error('❌ Razorpay payment error:', error);
            paymentProcessingRef.current = false;
            setPaymentProcessing(false);
            showToast(error, 'error', 'Unable to start payment. Please try again.');
            setLoading(false);
          }
        } else if (methods.includes('pay_after_work')) {
          application.paymentMethod = 'pay_after_work';
          application.paymentStatus = 'pending';
          await submitApp(application);
        } else if (methods.includes('cash')) {
          application.paymentMethod = 'cash';
          application.paymentStatus = 'completed';
          await submitApp(application);
        } else if (methods.includes('free')) {
          application.paymentMethod = 'free';
          application.paymentStatus = 'completed';
          application.charge = 0;
          await submitApp(application);
        } else {
          // Default to simple submission
          await submitApp(application);
        }
      } else {
        await submitApp(application);
      }
    } catch (error: any) {
      showToast(error, 'error', 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full min-h-screen px-2 sm:px-4 py-4 sm:py-8 flex flex-col">
      {paymentProcessing && (
        <div className="fixed inset-0 z-[3000] flex items-center justify-center bg-slate-950/70 p-6 backdrop-blur-sm" role="alert" aria-live="assertive">
          <div className="w-full max-w-md rounded-2xl bg-white p-6 text-center shadow-2xl sm:p-8">
            <div className="mx-auto mb-5 h-12 w-12 animate-spin rounded-full border-4 border-slate-200 border-t-primary" />
            <p className="text-base font-semibold leading-relaxed text-navy">Payment successful. Please wait while we confirm your payment and place your order. Do not refresh or go back.</p>
          </div>
        </div>
      )}
      <div className="flex-1 max-w-2xl mx-auto w-full bg-white rounded-2xl sm:rounded-3xl shadow-xl overflow-hidden">
        <div className="p-3 sm:p-6 md:p-10 space-y-4 sm:space-y-6 md:space-y-8 max-h-screen overflow-y-auto">
          <SEO 
            title={selectedSubService ? `${selectedSubService.name} - ${service.name} | India Cyber Cafe` : `${service.name} - Apply Online | India Cyber Cafe`}
            description={`Apply online for ${selectedSubService?.name || service.name} under ${service.name} at India Cyber Cafe. ${selectedSubService?.charge ? `Service charge: ₹${selectedSubService.charge}. ` : ''}Fast, secure & reliable digital assistance.`}
            keywords={`${selectedSubService?.name || ''}, ${service.name}, online application, India Cyber Cafe, apply online`}
            image={
              selectedSubService?.imageType === 'url' && selectedSubService.image && !selectedSubService.image.toLowerCase().endsWith('.mp4')
                ? selectedSubService.image
                : (service.iconType === 'url' && service.icon && !service.icon.toLowerCase().endsWith('.mp4') ? service.icon : undefined)
            }
            url={typeof window !== 'undefined' ? window.location.href : `https://b.indiacybercafe.com/services/${service.id}/${subserviceName || ''}`}
            ogType="article"
          />
          <div className="flex items-center justify-between gap-3">
            <button 
              onClick={() => navigate(`/services/${service.id}`)}
              className="flex items-center gap-1 sm:gap-2 text-navy font-bold hover:text-primary transition-all text-xs sm:text-sm md:text-base"
            >
              <IconRenderer name="arrow-left" className="w-3 h-3 sm:w-4 sm:h-4 md:w-5 md:h-5 shrink-0" />
              <span>Back</span>
            </button>

            <ShareButton
              data={selectedSubService ? getSubServiceShareData(service, selectedSubService) : getServiceShareData(service)}
              label="Share"
              variant="outline"
              size="sm"
              title={`Share ${selectedSubService?.name || service.name}`}
            />
          </div>

          <div className="text-center space-y-0.5 sm:space-y-1 md:space-y-2 mx-auto">
            <h2 className="text-lg sm:text-2xl md:text-3xl font-bold text-navy line-clamp-2 break-words">{service.name}</h2>
            <p className="text-[11px] sm:text-xs md:text-sm text-slate-500">Fill in the required details</p>
          </div>

          {subServiceNotFound && (
            <div className="p-2 sm:p-3 md:p-4 bg-amber-50 border border-amber-200 rounded-lg sm:rounded-xl flex items-start gap-2 sm:gap-3 overflow-hidden">
              <IconRenderer name="circle-exclamation" className="w-4 h-4 sm:w-5 sm:h-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="text-[10px] sm:text-xs md:text-sm text-amber-800 min-w-0">
                <p className="font-bold truncate">Sub-service not found</p>
                <p className="line-clamp-2">The requested link might be outdated. Select from below.</p>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
            {service.subservices.length > 0 && (
              <div className="space-y-1 sm:space-y-2">
                <label className="block font-bold text-navy text-sm sm:text-base truncate">Select Sub-Service *</label>
            <SelectDropdown
              className="input-field"
              value={String(service.subservices.findIndex(ss => ss.name === selectedSubService?.name))}
              onChange={(value) => {
                const sub = service.subservices[parseInt(value)];
                setSelectedSubService(sub);
                // Reset form data when sub-service changes
                setFormData({});
                setFiles({});
                if (sub && sub.name) {
                  navigate(`/services/${service.id}/${slugify(sub.name)}`);
                }
              }}
              options={[
                { value: '-1', label: '-- Choose a sub-service --' },
                ...(service.subservices || []).map((ss, i) => ({ value: String(i), label: ss.name })),
              ]}
            />
            {selectedSubService && (
              <div className="flex items-center gap-2 sm:gap-3 mt-2 flex-wrap">
                <span className="text-primary font-bold text-lg sm:text-xl">₹{selectedSubService.charge}</span>
                {selectedSubService.originalCharge && selectedSubService.originalCharge > selectedSubService.charge && (
                  <>
                    <span className="text-xs sm:text-sm text-slate-400 line-through">₹{selectedSubService.originalCharge}</span>
                    <span className="bg-green-100 text-green-600 text-[10px] font-bold px-2 py-0.5 rounded-full whitespace-nowrap">
                      {Math.round(((selectedSubService.originalCharge - selectedSubService.charge) / selectedSubService.originalCharge) * 100)}% OFF
                    </span>
                  </>
                )}
              </div>
            )}
          </div>
        )}

        {/* Sub-Service Image Display */}
        {selectedSubService && selectedSubService.image && (
          <div className="rounded-xl sm:rounded-2xl overflow-hidden border border-slate-200 shadow-md w-full">
            <div className={`flex items-center justify-center w-full bg-slate-100 ${
              selectedSubService.imageType === 'url' && selectedSubService.image
                ? 'aspect-video'
                : 'aspect-square'
            }`}>
              {selectedSubService.imageType === 'url' && selectedSubService.image ? (
                (selectedSubService.image || '').toLowerCase().endsWith('.mp4') ? (
                  <video src={secureUrl(selectedSubService.image)} className="w-full h-full object-contain" muted autoPlay loop />
                ) : (
                  <img src={secureUrl(selectedSubService.image)} alt={selectedSubService.name || 'Sub-service'} className="w-full h-full object-contain" />
                )
              ) : (
                <IconRenderer name={selectedSubService.image || 'file-text'} className="w-10 h-10 sm:w-14 sm:h-14 md:w-16 md:h-16 text-primary" />
              )}
            </div>
          </div>
        )}

        {(selectedSubService?.fields && selectedSubService.fields.length > 0 
          ? selectedSubService.fields 
          : service.fields).length > 0 ? (
          (selectedSubService?.fields && selectedSubService.fields.length > 0 
            ? selectedSubService.fields 
            : service.fields).map((field, i) => (
            <div key={i} className="space-y-1 sm:space-y-2 w-full">
              <label className="block font-bold text-navy text-xs sm:text-sm md:text-base truncate">{field.label}{field.required !== false && <span className="text-red-500"> *</span>}</label>
              {field.type === 'file' ? (
                <div className="relative w-full">
                  <input 
                    type="file" 
                    required={field.required !== false}
                    accept={field.accept}
                    multiple={field.multiple === true}
                    className="hidden" 
                    id={`file-${i}`}
                    onChange={e => handleFileChange(field.label, e.target.files, field.multiple === true, field.accept)}
                  />
                  <div className={field.multiple === true ? 'space-y-2' : ''}>
                    <label
                      htmlFor={`file-${i}`}
                      className="w-full flex flex-col items-center justify-center gap-1 p-3 sm:p-4 md:p-5 border-2 border-dashed border-slate-200 rounded-lg sm:rounded-xl cursor-pointer hover:border-primary hover:bg-primary/5 transition-all overflow-hidden"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#ff841b" className="w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6 shrink-0">
                      <path d="M15.26 22.2503H8.73998C3.82998 22.2503 1.72998 20.1503 1.72998 15.2403V15.1103C1.72998 10.6703 3.47998 8.53027 7.39998 8.16027C7.79998 8.13027 8.17998 8.43027 8.21998 8.84027C8.25998 9.25027 7.95998 9.62027 7.53998 9.66027C4.39998 9.95027 3.22998 11.4303 3.22998 15.1203V15.2503C3.22998 19.3203 4.66998 20.7603 8.73998 20.7603H15.26C19.33 20.7603 20.77 19.3203 20.77 15.2503V15.1203C20.77 11.4103 19.58 9.93027 16.38 9.66027C15.97 9.62027 15.66 9.26027 15.7 8.85027C15.74 8.44027 16.09 8.13027 16.51 8.17027C20.49 8.51027 22.27 10.6603 22.27 15.1303V15.2603C22.27 20.1503 20.17 22.2503 15.26 22.2503Z" fill="#ff841b"/>
                      <path d="M12 15.7501C11.59 15.7501 11.25 15.4101 11.25 15.0001V3.62012C11.25 3.21012 11.59 2.87012 12 2.87012C12.41 2.87012 12.75 3.21012 12.75 3.62012V15.0001C12.75 15.4101 12.41 15.7501 12 15.7501Z" fill="#ff841b"/>
                      <path d="M15.3501 6.60043C15.1601 6.60043 14.9701 6.53043 14.8201 6.38043L12.0001 3.56043L9.18009 6.38043C8.89009 6.67043 8.41009 6.67043 8.12009 6.38043C7.83009 6.09043 7.83009 5.61043 8.12009 5.32043L11.4701 1.97043C11.7601 1.68043 12.2401 1.68043 12.5301 1.97043L15.8801 5.32043C16.1701 5.61043 16.1701 6.09043 15.8801 6.38043C15.7401 6.53043 15.5401 6.60043 15.3501 6.60043Z" fill="#ff841b"/>
                      </svg>
                      <span className="text-[10px] sm:text-xs md:text-sm text-slate-500 font-medium text-center line-clamp-2 px-1 max-w-full">
                        {files[field.label]?.length
                          ? field.multiple === true ? `${files[field.label].length} file(s) selected` : files[field.label][0].name.substring(0, 20) + (files[field.label][0].name.length > 20 ? '...' : '')
                          : (Object.prototype.hasOwnProperty.call(field, 'placeholder') ? field.placeholder : 'Click to upload')}
                      </span>
                    </label>
                    {field.multiple === true && files[field.label]?.length > 0 && (
                      <div className="space-y-1">
                        {files[field.label].map((file, fileIndex) => (
                          <div key={`${file.name}-${file.lastModified}-${fileIndex}`} className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-500 min-w-0">
                            <span className="truncate flex-1" title={file.name}>{file.name}</span>
                            <span className="shrink-0 text-slate-400">{formatFileSize(file.size)}</span>
                            <button
                              type="button"
                              onClick={() => removeFile(field.label, fileIndex, `file-${i}`)}
                              className="text-red-500 hover:text-red-700 font-bold shrink-0 px-1"
                              aria-label={`Remove ${file.name}`}
                            >
                              X
                            </button>
                          </div>
                        ))}
                        {field.multiple === true && <div className="flex items-center gap-3">
                          <button
                            type="button"
                            onClick={() => document.getElementById(`file-${i}`)?.click()}
                            className="text-primary font-bold hover:underline text-xs"
                          >
                            Add More Files
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setFiles(prev => {
                                const next = { ...prev };
                                delete next[field.label];
                                return next;
                              });
                              const input = document.getElementById(`file-${i}`) as HTMLInputElement | null;
                              if (input) input.value = '';
                            }}
                            className="text-slate-500 font-bold hover:underline text-xs"
                          >
                            Clear All
                          </button>
                        </div>}
                      </div>
                    )}
                  </div>
                </div>
              ) : field.type === 'textarea' ? (
                <textarea 
                  required={field.required !== false}
                  placeholder={Object.prototype.hasOwnProperty.call(field, 'placeholder') ? field.placeholder : `Enter ${field.label.toLowerCase()}`}
                  className="input-field min-h-[70px] sm:min-h-[80px] md:min-h-[100px] text-[11px] sm:text-xs md:text-sm resize-vertical w-full"
                  onChange={e => handleInputChange(field.label, e.target.value)}
                />
              ) : field.type === 'multiselect' ? (
                <div className="space-y-2" role="group" aria-label={field.label}>
                  {(field.options || []).map((opt, idx) => {
                    const fieldKey = field.name || field.label;
                    const selectedValues = Array.isArray(formData[fieldKey]) ? formData[fieldKey] : [];
                    const optionId = `multiselect-${i}-${idx}`;

                    return (
                      <label
                        key={`${opt}-${idx}`}
                        htmlFor={optionId}
                        className="flex items-center gap-3 w-full px-3 py-2.5 rounded-xl border border-slate-200 bg-white cursor-pointer hover:border-primary hover:bg-primary/5 transition-all"
                      >
                        <input
                          id={optionId}
                          type="checkbox"
                          checked={selectedValues.includes(opt)}
                          onChange={e => {
                            setFormData(prev => {
                              const currentValues = Array.isArray(prev[fieldKey]) ? prev[fieldKey] : [];
                              const nextValues = e.target.checked
                                ? [...currentValues, opt]
                                : currentValues.filter(value => value !== opt);
                              return { ...prev, [fieldKey]: nextValues };
                            });
                          }}
                          className="h-4 w-4 shrink-0 accent-primary"
                        />
                        <span className="text-xs sm:text-sm text-navy font-medium">{opt}</span>
                      </label>
                    );
                  })}
                </div>
              ) : field.type === 'select' ? (
                <SelectDropdown
                  aria-label={field.label}
                  className="input-field text-xs sm:text-sm w-full"
                  value={formData[field.name || field.label] || ''}
                  onChange={value => handleInputChange(field.name || field.label, value)}
                  options={[
                    { value: '', label: Object.prototype.hasOwnProperty.call(field, 'placeholder') ? field.placeholder as string : `Select ${field.label}` },
                    ...(field.options || []).map(opt => ({ value: opt, label: opt })),
                  ]}
                />
              ) : (
                <input 
                  type={field.type} 
                  required={field.required !== false}
                  placeholder={Object.prototype.hasOwnProperty.call(field, 'placeholder') ? field.placeholder : `Enter ${field.label.toLowerCase()}`}
                  className="input-field text-xs sm:text-sm w-full"
                  onChange={e => handleInputChange(field.label, e.target.value)}
                />
              )}
              {field.help_text !== undefined && (
                <p className="text-xs text-slate-500">{field.help_text}</p>
              )}
            </div>
          ))
        ) : (
          <div className="p-4 sm:p-6 md:p-8 bg-slate-50 rounded-lg sm:rounded-xl md:rounded-2xl border border-dashed border-slate-200 text-center w-full overflow-hidden">
            <p className="text-[10px] sm:text-xs md:text-sm text-slate-500">No additional details required.</p>
          </div>
        )}

        {/* Statutory Privacy Notice & Declaration */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 sm:p-5 space-y-3 mt-4">
          <div className="flex items-start gap-2.5">
            <span className="text-base text-primary">🛡️</span>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-navy">Data Privacy & Service Declaration</h4>
              <p className="text-[11px] sm:text-xs text-slate-600 leading-relaxed mt-1">
                We collect your submitted details and uploaded documents solely to prepare, verify, and submit your requested application to the relevant government or institutional portals on your behalf. We do not sell or monetize personal information.
              </p>
            </div>
          </div>

          <label className="flex items-start gap-3 cursor-pointer pt-2 border-t border-slate-200">
            <input
              type="checkbox"
              checked={declarationChecked}
              onChange={e => setDeclarationChecked(e.target.checked)}
              className="mt-0.5 w-4 h-4 rounded text-primary focus:ring-primary/20 accent-primary shrink-0"
              required
            />
            <span className="text-[11px] sm:text-xs text-slate-700 leading-normal">
              I certify that all details and documents provided are authentic and truthful. I have read and agree to the{' '}
              <Link to="/legal/terms" target="_blank" className="text-primary font-semibold underline">Terms of Service</Link>,{' '}
              <Link to="/legal/privacy" target="_blank" className="text-primary font-semibold underline">Privacy Policy</Link>, and{' '}
              <Link to="/legal/refund" target="_blank" className="text-primary font-semibold underline">Refund Policy</Link>. If the applicant is a minor (under 18), I confirm this application is submitted with parental/guardian authorization.
            </span>
          </label>
        </div>

        <button 
          type="submit" 
          disabled={loading || paymentProcessing}
          className="btn-primary w-full py-2.5 sm:py-3 md:py-4 text-xs sm:text-sm md:text-base mt-4 relative overflow-hidden"
        >
          {loading ? (
            <div className="flex flex-col items-center justify-center">
              <span className="flex items-center gap-2">
                <div className="w-3 h-3 sm:w-4 sm:h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span className="text-xs sm:text-sm">
                  {uploadProgress.total > 0 ? `Uploading (${uploadProgress.current}/${uploadProgress.total})...` : 'Submitting...'}
                </span>
              </span>
              {uploadProgress.total > 0 && (
                <div className="absolute bottom-0 left-0 h-1 bg-white/30 transition-all duration-300" style={{ width: `${(uploadProgress.current / uploadProgress.total) * 100}%` }} />
              )}
            </div>
          ) : selectedSubService ? 'Proceed to Payment' : 'Submit Application'}
        </button>
        </form>
        </div>
      </div>
    </div>
  );
}
