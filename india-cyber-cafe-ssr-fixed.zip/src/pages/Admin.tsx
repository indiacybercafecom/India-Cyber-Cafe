import { useEffect, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Application, UserProfile, Service, PaymentGateway, Product, ProductCategory, Order, ProductReview, FormDocument, DocumentCategory, PrivacyRequest, PrivacyRequestStatus } from '../types';
import { IconRenderer } from '../components/Icons';
import { SelectDropdown } from '../components/SelectDropdown';
import { showToast } from '../components/Toast';
import { ErrorBoundary } from '../components/ErrorBoundary';
import { GatewayModal } from '../components/GatewayModal';
import { ConfirmationModal } from '../components/ConfirmationModal';
import { ProductModal } from '../components/ProductModal';
import { CategoryModal } from '../components/CategoryModal';
import { DocumentModal } from '../components/DocumentModal';
import { DocumentCategoryModal } from '../components/DocumentCategoryModal';
import { OrderManageModal } from '../components/OrderManageModal';
import { exportDataComprehensive } from '../services/exportService';
import { generateSlug } from '../utils/slugGenerator';
import { fetchAdminPrivacyRequests, updatePrivacyRequestStatus, PRIVACY_REQUEST_CATEGORIES } from '../services/privacyRequestService';
import { UserAvatar } from '../components/UserAvatar';
const getEmbeddedTimestamp = (id: string | undefined): number | null => {
  const match = id?.match(/^ICC(?:\/STORE)?-(\d{2})(\d{2})(\d{4})-(\d{2})(\d{2})(\d{2})-/);
  if (!match) return null;

  const [, day, month, year, hours, minutes, seconds] = match;
  return Date.UTC(Number(year), Number(month) - 1, Number(day), Number(hours), Number(minutes), Number(seconds));
};

const getRecordTimestamp = (id: string | undefined, fallbackDate: string | undefined): number => {
  const parsedFallback = fallbackDate ? Date.parse(fallbackDate) : 0;
  return getEmbeddedTimestamp(id) ?? (Number.isNaN(parsedFallback) ? 0 : parsedFallback);
};

interface AdminProps {
  applications: Application[];
  users: UserProfile[];
  services: Service[];
  gateways: PaymentGateway[];
  products?: Product[];
  productCategories?: ProductCategory[];
  documents?: FormDocument[];
  documentCategories?: DocumentCategory[];
  orders?: Order[];
  productReviews?: ProductReview[];
  onViewApp: (app: Application) => void;
  onDeleteApp: (id: string) => Promise<void>;
  onEditService: (service: Service) => void;
  onAddService: () => void;
  onDeleteService: (id: string) => Promise<void>;
  onManageUser: (user: UserProfile) => void;
  onAddGateway: (gateway: PaymentGateway) => void;
  onUpdateGateway: (id: string, gateway: Partial<PaymentGateway>) => void;
  onDeleteGateway: (id: string) => Promise<void>;
  onEditProduct?: (id: string, product: any) => Promise<void>;
  onAddProduct?: () => void;
  onDeleteProduct?: (id: string) => Promise<void>;
  onViewOrder?: (order: Order) => void;
  onUpdateOrder?: (id: string, data: Partial<Order>) => Promise<void>;
  onDeleteOrder?: (id: string) => Promise<void>;
  onAddCategory?: (category: ProductCategory) => Promise<void>;
  onUpdateCategory?: (id: string, category: Partial<ProductCategory>) => Promise<void>;
  onDeleteCategory?: (id: string) => Promise<void>;
  onSaveDocument?: (data: Omit<FormDocument, 'id'>, id?: string) => Promise<void>;
  onDeleteDocument?: (id: string) => Promise<void>;
  onSaveDocumentCategory?: (category: DocumentCategory, id?: string) => Promise<void>;
  onDeleteDocumentCategory?: (id: string) => Promise<void>;
  onDeleteProductReview?: (id: string) => Promise<void>;
  onUpdateProductReview?: (id: string, data: Partial<ProductReview>) => Promise<void>;
  currentUser?: UserProfile;
}

export function Admin({ 
  applications, 
  users, 
  services, 
  gateways,
  products = [],
  productCategories = [],
  documents = [],
  documentCategories = [],
  orders = [],
  productReviews = [],
  onViewApp, 
  onDeleteApp,
  onEditService, 
  onAddService,
  onDeleteService,
  onManageUser,
  onAddGateway,
  onUpdateGateway,
  onDeleteGateway,
  onEditProduct,
  onAddProduct,
  onDeleteProduct,
  onViewOrder,
  onUpdateOrder,
  onDeleteOrder,
  onAddCategory,
  onUpdateCategory,
  onDeleteCategory,
  onSaveDocument,
  onDeleteDocument,
  onSaveDocumentCategory,
  onDeleteDocumentCategory,
  onDeleteProductReview,
  currentUser,
  onUpdateProductReview
}: AdminProps) {
  const navigate = useNavigate();
  const location = useLocation();
  type AdminTab = 'apps' | 'users' | 'services' | 'payments' | 'products' | 'documents' | 'orders' | 'reviews' | 'privacy';
  const tabFromPath = (pathname: string): AdminTab => {
    const section = pathname.split('/')[2];
    const sectionMap: Record<string, AdminTab> = {
      applications: 'apps',
      users: 'users',
      services: 'services',
      store: 'products',
      pdfs: 'documents',
      orders: 'orders',
      reviews: 'reviews',
      payments: 'payments',
      'privacy-requests': 'privacy',
    };
    return sectionMap[section] || 'apps';
  };
  const pathFromTab = (nextTab: AdminTab) => {
    const sectionMap: Record<AdminTab, string> = {
      apps: 'applications',
      users: 'users',
      services: 'services',
      products: 'store',
      documents: 'pdfs',
      orders: 'orders',
      reviews: 'reviews',
      payments: 'payments',
      privacy: 'privacy-requests',
    };
    return `/admin/${sectionMap[nextTab]}`;
  };
  const [tab, setTab] = useState<AdminTab>(() => tabFromPath(location.pathname));
  const [selectedGateway, setSelectedGateway] = useState<PaymentGateway | null>(null);
  const [isGatewayModalOpen, setIsGatewayModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory | null>(null);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isOrderDetailModalOpen, setIsOrderDetailModalOpen] = useState(false);
  const [selectedReview, setSelectedReview] = useState<ProductReview | null>(null);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [exportFormat, setExportFormat] = useState<'excel' | 'json'>('excel');
  const [copiedDocId, setCopiedDocId] = useState<string | null>(null);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isSectionDropdownOpen, setIsSectionDropdownOpen] = useState(false);
  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false);
  const sectionDropdownRef = useRef<HTMLDivElement>(null);
  const roleDropdownRef = useRef<HTMLDivElement>(null);

  // Privacy requests state
  const [privacyRequests, setPrivacyRequests] = useState<PrivacyRequest[]>([]);
  const [privacyLoading, setPrivacyLoading] = useState(false);
  const [privacyStatusFilter, setPrivacyStatusFilter] = useState<'all' | PrivacyRequestStatus>('all');
  const [searchPrivacy, setSearchPrivacy] = useState('');
  const [selectedPrivacyReq, setSelectedPrivacyReq] = useState<PrivacyRequest | null>(null);
  const [adminNoteText, setAdminNoteText] = useState('');
  const [isPrivacyModalOpen, setIsPrivacyModalOpen] = useState(false);
  const [updatingPrivacy, setUpdatingPrivacy] = useState(false);

  const sectionOptions = [
    { id: 'apps', label: 'Applications', icon: 'clipboard-list' },
    { id: 'orders', label: 'Orders', icon: 'package' },
    { id: 'users', label: 'Users', icon: 'users' },
    { id: 'services', label: 'Services', icon: 'layers' },
    { id: 'products', label: 'Store', icon: 'shopping-bag' },
    { id: 'documents', label: 'PDFs', icon: 'file-text' },
    { id: 'reviews', label: 'Reviews', icon: 'star' },
    { id: 'payments', label: 'Payments', icon: 'credit-card' },
    { id: 'privacy', label: 'Privacy & Grievances', icon: 'shield-check' },
  ] as const;
  const selectedSection = sectionOptions.find(option => option.id === tab) || sectionOptions[0];

  useEffect(() => {
    const nextTab = tabFromPath(location.pathname);
    setTab(nextTab);
    if (location.pathname === '/admin' || !location.pathname.startsWith('/admin/')) {
      navigate('/admin/applications', { replace: true });
    }
  }, [location.pathname, navigate]);

  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      if (sectionDropdownRef.current && !sectionDropdownRef.current.contains(event.target as Node)) {
        setIsSectionDropdownOpen(false);
      }
      if (roleDropdownRef.current && !roleDropdownRef.current.contains(event.target as Node)) {
        setIsRoleDropdownOpen(false);
      }
    };
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsSectionDropdownOpen(false);
        setIsRoleDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleOutsideClick);
    document.addEventListener('keydown', handleEscape);
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
      document.removeEventListener('keydown', handleEscape);
    };
  }, []);
  
  // Search States
  const [searchApps, setSearchApps] = useState('');
  const [searchUsers, setSearchUsers] = useState('');
  const [searchServices, setSearchServices] = useState('');
  const [searchPayments, setSearchPayments] = useState('');
  const [searchProducts, setSearchProducts] = useState('');
  const [searchDocuments, setSearchDocuments] = useState('');
  const [searchOrders, setSearchOrders] = useState('');
  const [searchReviews, setSearchReviews] = useState('');
  const [selectedDocument, setSelectedDocument] = useState<FormDocument | null>(null);
  const [isDocumentModalOpen, setIsDocumentModalOpen] = useState(false);
  const [selectedDocumentCategory, setSelectedDocumentCategory] = useState<DocumentCategory | null>(null);
  const [isDocumentCategoryModalOpen, setIsDocumentCategoryModalOpen] = useState(false);
  const [userRoleFilter, setUserRoleFilter] = useState<'all' | 'user' | 'operator' | 'admin'>('all');

  // Confirmation Modal State
  const [confirmConfig, setConfirmConfig] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
    type: 'danger' | 'warning' | 'info';
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
    type: 'warning'
  });

  const handleSaveGateway = async (gateway: PaymentGateway) => {
    try {
      if (selectedGateway) {
        await onUpdateGateway(selectedGateway.id, gateway);
        showToast('Gateway updated successfully!');
      } else {
        await onAddGateway(gateway);
        showToast('Gateway added successfully!');
      }
      setIsGatewayModalOpen(false);
      setSelectedGateway(null);
    } catch (error: any) {
      showToast(error, 'error', 'Failed to save gateway');
    }
  };

  const handleDeleteGateway = (id: string) => {
    setConfirmConfig({
      isOpen: true,
      title: 'Delete Gateway',
      message: 'Are you sure you want to delete this payment gateway? This action cannot be undone.',
      type: 'danger',
      onConfirm: async () => {
        try {
          await onDeleteGateway(id);
          showToast('Gateway deleted successfully', 'success');
        } catch (error: any) {
          showToast(error, 'error', 'Failed to delete gateway');
        }
      }
    });
  };

  const handleDeleteProduct = (id: string) => {
    setConfirmConfig({
      isOpen: true,
      title: 'Delete Product',
      message: 'Are you sure you want to delete this product? This action cannot be undone.',
      type: 'danger',
      onConfirm: async () => {
        try {
          if (onDeleteProduct) {
            await onDeleteProduct(id);
            showToast('Product deleted successfully');
          }
        } catch (error: any) {
          showToast(error, 'error', 'Failed to delete product');
        }
      }
    });
  };

  const handleDeleteCategory = (id: string) => {
    setConfirmConfig({
      isOpen: true,
      title: 'Delete Category',
      message: 'Are you sure you want to delete this category? Products in this category will not be affected.',
      type: 'danger',
      onConfirm: async () => {
        try {
          if (onDeleteCategory) {
            await onDeleteCategory(id);
            showToast('Category deleted successfully');
          }
        } catch (error: any) {
          showToast(error, 'error', 'Failed to delete category');
        }
      }
    });
  };

  const handleDeleteDocument = (id: string) => {
    setConfirmConfig({
      isOpen: true,
      title: 'Delete PDF',
      message: 'Are you sure you want to delete this PDF? This action cannot be undone.',
      type: 'danger',
      onConfirm: async () => {
        try { await onDeleteDocument?.(id); showToast('PDF deleted successfully'); }
        catch (error: any) { showToast(error, 'error', 'Failed to delete PDF'); }
      }
    });
  };

  const handleDeleteDocumentCategory = (id: string) => {
    setConfirmConfig({
      isOpen: true,
      title: 'Delete PDF Category',
      message: 'Are you sure you want to delete this PDF category?',
      type: 'danger',
      onConfirm: async () => {
        try { await onDeleteDocumentCategory?.(id); showToast('PDF category deleted successfully'); }
        catch (error: any) { showToast(error, 'error', 'Failed to delete PDF category'); }
      }
    });
  };

  const handleDeleteOrder = (id: string) => {
    setConfirmConfig({
      isOpen: true,
      title: 'Delete Order',
      message: 'Are you sure you want to delete this order? This action cannot be undone.',
      type: 'danger',
      onConfirm: async () => {
        try {
          if (onDeleteOrder) {
            await onDeleteOrder(id);
            showToast('Order deleted successfully');
          }
        } catch (error: any) {
          showToast(error, 'error', 'Failed to delete order');
        }
      }
    });
  };

  const handleDeleteReview = (id: string) => {
    setConfirmConfig({
      isOpen: true,
      title: 'Delete Review',
      message: 'Are you sure you want to delete this review? This action cannot be undone.',
      type: 'danger',
      onConfirm: async () => {
        try {
          if (onDeleteProductReview) {
            await onDeleteProductReview(id);
            showToast('Review deleted successfully');
          }
        } catch (error: any) {
          showToast(error, 'error', 'Failed to delete review');
        }
      }
    });
  };

  const exportToExcel = (type: 'apps' | 'users' | 'services' | 'payments' | 'products' | 'documents' | 'orders' | 'reviews' | 'all' = 'apps') => {
    try {
      exportDataComprehensive(type, {
        applications,
        users,
        services,
        gateways,
        products,
        productCategories,
        documents,
        documentCategories,
        orders,
        productReviews
      }, {
        format: exportFormat
      });
      
      const formatName = exportFormat === 'json' ? 'JSON' : 'Excel';
      showToast(`Export ${type} as ${formatName} successful!`, 'success');
    } catch (error: any) {
      showToast(error, 'error', 'Export failed. Please try again.');
    }
  };

  const handleDeleteApp = (id: string) => {
    setConfirmConfig({
      isOpen: true,
      title: 'Delete Application',
      message: 'Are you sure you want to delete this application? All associated data will be permanently removed.',
      type: 'danger',
      onConfirm: async () => {
        try {
          await onDeleteApp(id);
          showToast('Application deleted successfully', 'success');
        } catch (error: any) {
          showToast(error, 'error', 'Failed to delete application');
        }
      }
    });
  };

  const handleDeleteService = (id: string) => {
    setConfirmConfig({
      isOpen: true,
      title: 'Delete Service',
      message: 'Are you sure you want to delete this service? This will remove it from the public services list.',
      type: 'danger',
      onConfirm: async () => {
        try {
          await onDeleteService(id);
          showToast('Service deleted successfully', 'success');
        } catch (error: any) {
          showToast(error, 'error', 'Failed to delete service');
        }
      }
    });
  };

  // Filtered Lists
  const filteredApps = applications.filter(app => 
    (app.id || '').toLowerCase().includes(searchApps.toLowerCase()) ||
    (app.name || '').toLowerCase().includes(searchApps.toLowerCase()) ||
    (app.email || '').toLowerCase().includes(searchApps.toLowerCase()) ||
    (app.serviceName || '').toLowerCase().includes(searchApps.toLowerCase())
  ).sort((a, b) => getRecordTimestamp(b.id, b.date) - getRecordTimestamp(a.id, a.date));

  const filteredUsers = users
    .filter(u => 
      ((u.name || '').toLowerCase().includes(searchUsers.toLowerCase()) ||
       (u.email || '').toLowerCase().includes(searchUsers.toLowerCase()) ||
       ((u.phone || '').includes(searchUsers))) &&
      (userRoleFilter === 'all' || u.role === userRoleFilter)
    )
    .sort((a, b) => {
      // Sort by creation date - most recent first
      return b.createdAt - a.createdAt;
    });

  const filteredServices = services.filter(s => 
    (s.name || '').toLowerCase().includes(searchServices.toLowerCase()) ||
    (s.description || '').toLowerCase().includes(searchServices.toLowerCase())
  );

  const filteredGateways = gateways.filter(g => 
    (g.name || '').toLowerCase().includes(searchPayments.toLowerCase()) ||
    (g.type || '').toLowerCase().includes(searchPayments.toLowerCase())
  );

  const filteredProducts = products.filter(p =>
    (p.name || '').toLowerCase().includes(searchProducts.toLowerCase()) ||
    (p.shortDescription || '').toLowerCase().includes(searchProducts.toLowerCase())
  );

  const filteredDocuments = documents.filter(document =>
    document.name.toLowerCase().includes(searchDocuments.toLowerCase()) ||
    document.description.toLowerCase().includes(searchDocuments.toLowerCase()) ||
    document.category.toLowerCase().includes(searchDocuments.toLowerCase())
  );

  const filteredOrders = (orders && Array.isArray(orders) ? orders : [])
    .filter(o => {
      if (!o) return false;
      const orderIdMatch = o.id && typeof o.id === 'string' && o.id.toLowerCase().includes(searchOrders.toLowerCase());
      const emailMatch = o.email && typeof o.email === 'string' && o.email.toLowerCase().includes(searchOrders.toLowerCase());
      return orderIdMatch || emailMatch;
    })
    .sort((a, b) => {
      return getRecordTimestamp(b?.id, b?.createdAt) - getRecordTimestamp(a?.id, a?.createdAt);
    });

  // Privacy requests loading and filtering
  useEffect(() => {
    if (tab === 'privacy') {
      setPrivacyLoading(true);
      fetchAdminPrivacyRequests()
        .then(reqs => {
          setPrivacyRequests(reqs);
          setPrivacyLoading(false);
        })
        .catch(err => {
          console.error("Privacy load error:", err);
          setPrivacyLoading(false);
        });
    }
  }, [tab]);

  const filteredPrivacyRequests = privacyRequests.filter(req => {
    const matchesStatus = privacyStatusFilter === 'all' || req.status === privacyStatusFilter;
    const matchesSearch =
      !searchPrivacy ||
      req.id.toLowerCase().includes(searchPrivacy.toLowerCase()) ||
      req.name.toLowerCase().includes(searchPrivacy.toLowerCase()) ||
      req.email.toLowerCase().includes(searchPrivacy.toLowerCase()) ||
      req.category.toLowerCase().includes(searchPrivacy.toLowerCase()) ||
      (req.referenceId && req.referenceId.toLowerCase().includes(searchPrivacy.toLowerCase()));
    return matchesStatus && matchesSearch;
  });

  const handleOpenPrivacyModal = (req: PrivacyRequest) => {
    setSelectedPrivacyReq(req);
    setAdminNoteText(req.adminNotes || '');
    setIsPrivacyModalOpen(true);
  };

  const handleSavePrivacyStatus = async (newStatus: PrivacyRequestStatus) => {
    if (!selectedPrivacyReq) return;
    setUpdatingPrivacy(true);
    try {
      const res = await updatePrivacyRequestStatus(selectedPrivacyReq.id, newStatus, adminNoteText);
      if (res.success) {
        showToast('Privacy request status updated.', 'success');
        setPrivacyRequests(prev =>
          prev.map(item =>
            item.id === selectedPrivacyReq.id
              ? {
                  ...item,
                  status: newStatus,
                  adminNotes: adminNoteText,
                  updatedAt: new Date().toISOString(),
                  resolvedAt: newStatus === 'resolved' ? new Date().toISOString() : item.resolvedAt,
                }
              : item
          )
        );
        setIsPrivacyModalOpen(false);
        setSelectedPrivacyReq(null);
      } else {
        showToast(res.error, 'error', 'Failed to update request');
      }
    } catch (err: any) {
      showToast(err, 'error', 'Error updating status');
    } finally {
      setUpdatingPrivacy(false);
    }
  };

  const exportPrivacyRequests = () => {
    try {
      const dataToExport = filteredPrivacyRequests.map(r => ({
        Ticket_ID: r.id,
        Date: new Date(r.createdAt).toLocaleString('en-IN'),
        Category: r.category,
        Status: r.status,
        Name: r.name,
        Email: r.email,
        Phone: r.phone || '',
        Reference_ID: r.referenceId || '',
        Description: r.description,
        Resolution_Notes: r.adminNotes || '',
        Resolved_Date: r.resolvedAt ? new Date(r.resolvedAt).toLocaleString('en-IN') : ''
      }));
      const blob = new Blob([JSON.stringify(dataToExport, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `privacy_grievance_requests_${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
      showToast('Privacy requests exported successfully', 'success');
    } catch (err: any) {
      showToast(err, 'error', 'Export failed. Please try again.');
    }
  };


  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h2 className="text-4xl font-bold text-navy">Admin Panel</h2>
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <div ref={sectionDropdownRef} className="relative min-w-52">
            <button
              type="button"
              onClick={() => setIsSectionDropdownOpen(isOpen => !isOpen)}
              aria-expanded={isSectionDropdownOpen}
              aria-haspopup="listbox"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all bg-white font-bold text-navy text-sm flex items-center justify-between gap-3"
            >
              <span className="flex items-center gap-2">
                <IconRenderer name={selectedSection.icon} className="w-4 h-4 text-primary" />
                {selectedSection.label}
              </span>
              <IconRenderer name={isSectionDropdownOpen ? 'chevron-up' : 'chevron-down'} className="w-4 h-4 text-slate-500" />
            </button>

            {isSectionDropdownOpen && (
              <div
                role="listbox"
                aria-label="Admin sections"
                className="absolute top-full left-0 right-0 mt-2 z-50 rounded-xl border border-slate-200 bg-white p-1.5 shadow-xl"
              >
                {sectionOptions.map(option => (
                  <button
                    key={option.id}
                    type="button"
                    role="option"
                    aria-selected={tab === option.id}
                    onClick={() => {
                      const nextTab = option.id as AdminTab;
                      setTab(nextTab);
                      navigate(pathFromTab(nextTab));
                      setIsSectionDropdownOpen(false);
                    }}
                    className={`w-full px-3 py-2.5 rounded-lg flex items-center gap-3 text-left text-sm font-semibold transition-colors ${
                      tab === option.id ? 'bg-primary/10 text-primary' : 'text-slate-600 hover:bg-slate-50 hover:text-navy'
                    }`}
                  >
                    <IconRenderer name={option.icon} className="w-4 h-4" />
                    <span className="flex-1">{option.label}</span>
                    {tab === option.id && <IconRenderer name="check" className="w-4 h-4" />}
                  </button>
                ))}
              </div>
            )}
          </div>
          <button
            onClick={() => setIsExportModalOpen(true)}
            className="bg-navy text-white px-6 py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-navy-light transition-all shadow-lg whitespace-nowrap"
          >
            <IconRenderer name="file-export" className="w-5 h-5" />
            Export
          </button>
        </div>
      </div>

      {tab === 'apps' && (
        <div className="space-y-4">
          <div className="relative max-w-md">
            <IconRenderer name="magnifying-glass" className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search applications (ID, Name, Email, Service)..." 
              className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
              value={searchApps}
              onChange={e => setSearchApps(e.target.value)}
            />
          </div>
          <div className="bg-white rounded-3xl shadow-xl overflow-hidden">
            <div className="overflow-x-auto hidden sm:block">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-navy text-white">
                    <th className="p-6 font-bold">ID</th>
                    <th className="p-6 font-bold">User</th>
                    <th className="p-6 font-bold">Service</th>
                    <th className="p-6 font-bold">Operator</th>
                    <th className="p-6 font-bold">Status</th>
                    <th className="p-6 font-bold">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredApps.map(app => (
                    <tr key={app.id} className="hover:bg-slate-50 transition-colors">
                      <td className="p-6 font-medium text-slate-600">{app.id}</td>
                      <td className="p-6">
                        <div className="font-bold text-navy">{app.name}</div>
                        <div className="text-xs text-slate-400">{app.email}</div>
                      </td>
                      <td className="p-6 font-bold text-navy">{app.serviceName}</td>
                      <td className="p-6 text-slate-500 font-medium">{app.assignedTo || 'Unassigned'}</td>
                      <td className="p-6">
                        <span className={`badge ${
                          app.status === 'completed' ? 'bg-green-500' : 
                          app.status === 'processing' ? 'bg-orange-500' : 
                          app.status === 'rejected' ? 'bg-red-500' : 'bg-blue-500'
                        }`}>
                          {app.status}
                        </span>
                      </td>
                      <td className="p-6">
                        <div className="flex gap-2">
                          <button onClick={() => onViewApp(app)} className="btn-primary py-2 px-4 text-sm">View</button>
                          <button onClick={() => handleDeleteApp(app.id)} className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-all">
                            <IconRenderer name="trash" className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {filteredApps.length === 0 && (
                    <tr>
                      <td colSpan={6} className="p-10 text-center text-slate-400 italic">No applications found.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Mobile View for Apps */}
            <div className="sm:hidden divide-y divide-slate-100">
              {filteredApps.map(app => (
                <div key={app.id} className="p-6 space-y-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="text-xs text-slate-400 font-bold uppercase tracking-wider mb-1">{app.id}</div>
                      <div className="font-bold text-navy">{app.name}</div>
                      <div className="text-xs text-slate-500">{app.serviceName}</div>
                    </div>
                    <span className={`badge ${
                      app.status === 'completed' ? 'bg-green-500' : 
                      app.status === 'processing' ? 'bg-orange-500' : 
                      app.status === 'rejected' ? 'bg-red-500' : 'bg-blue-500'
                    }`}>
                      {app.status}
                    </span>
                  </div>
                  <div className="flex justify-between items-center pt-2">
                    <div className="text-xs text-slate-400 italic">
                      By: {app.assignedTo || 'Unassigned'}
                    </div>
                    <div className="flex gap-2">
                      <button onClick={() => onViewApp(app)} className="btn-primary py-2 px-4 text-xs">View</button>
                      <button onClick={() => handleDeleteApp(app.id)} className="p-2 text-red-500 bg-red-50 rounded-lg">
                        <IconRenderer name="trash" className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
              {filteredApps.length === 0 && (
                <div className="p-10 text-center text-slate-400 italic">No applications found.</div>
              )}
            </div>
          </div>
        </div>
      )}

      {tab === 'users' && (
        <div className="space-y-4">
          <div className="w-full flex flex-col sm:flex-row gap-4 justify-between">
            <div className="relative flex-1 max-w-md">
              <IconRenderer name="magnifying-glass" className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
              <input 
                type="text" 
                placeholder="Search users (Name, Email, Phone)..." 
                className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                value={searchUsers}
                onChange={e => setSearchUsers(e.target.value)}
              />
            </div>
            <div ref={roleDropdownRef} className="relative w-full sm:w-40 sm:ml-auto sm:self-end">
              <button
                type="button"
                onClick={() => setIsRoleDropdownOpen(isOpen => !isOpen)}
                aria-expanded={isRoleDropdownOpen}
                aria-haspopup="listbox"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all bg-white font-bold text-navy flex items-center justify-between gap-3"
              >
                <span>{userRoleFilter === 'all' ? 'All Roles' : userRoleFilter === 'user' ? 'Users' : userRoleFilter === 'operator' ? 'Operators' : 'Admins'}</span>
                <span
                  aria-hidden="true"
                  className={`h-2 w-2 shrink-0 border-r-2 border-b-2 border-slate-500 transition-transform ${isRoleDropdownOpen ? 'rotate-[225deg] -translate-y-0.5' : 'rotate-45 -translate-y-0.5'}`}
                />
              </button>

              {isRoleDropdownOpen && (
                <div
                  role="listbox"
                  aria-label="Filter users by role"
                  className="absolute top-full left-0 right-0 mt-2 z-50 rounded-xl border border-slate-200 bg-white p-1.5 shadow-xl"
                >
                  {[
                    { value: 'all', label: 'All Roles' },
                    { value: 'user', label: 'Users' },
                    { value: 'operator', label: 'Operators' },
                    { value: 'admin', label: 'Admins' },
                  ].map(option => (
                    <button
                      key={option.value}
                      type="button"
                      role="option"
                      aria-selected={userRoleFilter === option.value}
                      onClick={() => {
                        setUserRoleFilter(option.value as typeof userRoleFilter);
                        setIsRoleDropdownOpen(false);
                      }}
                      className={`w-full px-3 py-2.5 rounded-lg text-left text-sm font-semibold transition-colors ${
                        userRoleFilter === option.value ? 'bg-primary/10 text-primary' : 'text-slate-600 hover:bg-slate-50 hover:text-navy'
                      }`}
                    >
                      <span className="flex items-center justify-between gap-3">
                        {option.label}
                        {userRoleFilter === option.value && <IconRenderer name="check" className="w-4 h-4 text-primary" />}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
          <div className="bg-white rounded-3xl shadow-xl overflow-hidden">
            <div className="overflow-x-auto hidden sm:block">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-navy text-white">
                    <th className="p-6 font-bold">Avatar</th>
                    <th className="p-6 font-bold">Name</th>
                    <th className="p-6 font-bold">Email</th>
                    <th className="p-6 font-bold">Mobile</th>
                    <th className="p-6 font-bold">Role</th>
                    <th className="p-6 font-bold">Manage</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredUsers.map(u => (
                    <tr key={u.uid} className="hover:bg-slate-50 transition-colors">
                      <td className="p-6">
                        <UserAvatar user={u} className="w-10 h-10 rounded-full object-cover border-2 border-slate-100" />
                      </td>
                      <td className="p-6 font-bold text-navy">{u.name}</td>
                      <td className="p-6 text-sm text-slate-600">{u.email}</td>
                      <td className="p-6 text-sm text-slate-600">{u.phone || 'N/A'}</td>
                      <td className="p-6">
                        <span className={`badge ${
                          u.role === 'admin' ? 'bg-red-500' : 
                          u.role === 'operator' ? 'bg-blue-500' : 'bg-slate-500'
                        }`}>
                          {u.role}
                        </span>
                      </td>
                      <td className="p-6">
                        <button 
                          onClick={() => onManageUser(u)}
                          className="btn-outline py-2 px-4 text-sm"
                        >
                          Manage
                        </button>
                      </td>
                    </tr>
                  ))}
                  {filteredUsers.length === 0 && (
                    <tr>
                      <td colSpan={6} className="p-10 text-center text-slate-400 italic">No users found.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Mobile View for Users */}
            <div className="sm:hidden divide-y divide-slate-100">
              {filteredUsers.map(u => (
                <div key={u.uid} className="p-6 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <UserAvatar user={u} className="w-12 h-12 rounded-full object-cover border-2 border-primary/20" />
                    <div className="min-w-0">
                      <div className="font-bold text-navy">{u.name}</div>
                      <div className="text-xs text-slate-400 truncate">{u.email}</div>
                      <div className="text-xs text-slate-400">{u.phone || 'No phone'}</div>
                      <span className={`badge mt-1 inline-block text-xs ${
                        u.role === 'admin' ? 'bg-red-500' : 
                        u.role === 'operator' ? 'bg-blue-500' : 'bg-slate-500'
                      }`}>
                        {u.role}
                      </span>
                    </div>
                  </div>
                  <button 
                    onClick={() => onManageUser(u)}
                    className="p-2 bg-slate-100 rounded-xl text-navy flex-shrink-0"
                  >
                    <IconRenderer name="user-pen" className="w-5 h-5" />
                  </button>
                </div>
              ))}
              {filteredUsers.length === 0 && (
                <div className="p-10 text-center text-slate-400 italic">No users found.</div>
              )}
            </div>
          </div>
        </div>
      )}

      {tab === 'services' && (
        <ErrorBoundary>
          <div className="space-y-4">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="relative w-full max-w-md">
                <IconRenderer name="magnifying-glass" className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Search services..." 
                  className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                  value={searchServices}
                  onChange={e => setSearchServices(e.target.value)}
                />
              </div>
              <button onClick={onAddService} className="w-full md:w-auto btn-primary flex items-center justify-center gap-2 px-8">
                <IconRenderer name="plus" className="w-5 h-5" />
                Create Service
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredServices.map(s => (
                <div key={s.id} className="bg-white p-6 rounded-2xl shadow-md border-2 border-transparent hover:border-primary transition-all group relative">
                  <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-all">
                    <button onClick={() => onEditService(s)} className="p-2 bg-primary text-white rounded-lg hover:scale-110 transition-all"><IconRenderer name="user-pen" className="w-4 h-4" /></button>
                    <button onClick={() => handleDeleteService(s.id)} className="p-2 bg-red-500 text-white rounded-lg hover:scale-110 transition-all"><IconRenderer name="trash" className="w-4 h-4" /></button>
                  </div>
                  <IconRenderer name={s.icon || 'layers'} className="w-12 h-12 text-primary mb-4" />
                  <h3 className="text-lg font-bold text-navy">{s.name}</h3>
                  <p className="text-slate-400 text-sm mt-2 line-clamp-2">{s.description}</p>
                </div>
              ))}
              {filteredServices.length === 0 && (
                <div className="col-span-full p-10 text-center text-slate-400 italic">No services found.</div>
              )}
            </div>
          </div>
        </ErrorBoundary>
      )}

      {tab === 'payments' && (
        <div className="space-y-4">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="relative w-full max-w-md">
              <IconRenderer name="magnifying-glass" className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
              <input 
                type="text" 
                placeholder="Search gateways..." 
                className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                value={searchPayments}
                onChange={e => setSearchPayments(e.target.value)}
              />
            </div>
            <button 
              onClick={() => { setSelectedGateway(null); setIsGatewayModalOpen(true); }}
              className="w-full md:w-auto btn-primary py-3 px-8 text-sm flex items-center justify-center gap-2"
            >
              <IconRenderer name="plus" className="w-4 h-4" />
              Add Gateway
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredGateways.map(g => (
              <div key={g.id} className={`bg-white p-6 rounded-2xl shadow-md border-2 transition-all ${g.active ? 'border-green-500' : 'border-slate-100 opacity-60'}`}>
                <div className="flex justify-between items-start mb-4">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest bg-slate-50 px-2 py-1 rounded">{g.type}</span>
                  <span className={`badge ${g.active ? 'bg-green-500' : 'bg-slate-400'}`}>{g.active ? 'Active' : 'Inactive'}</span>
                </div>
                <h3 className="text-xl font-bold text-navy mb-2">{g.name}</h3>
                <p className="text-slate-500 text-sm mb-6 line-clamp-2">{g.description}</p>
                <div className="flex gap-2">
                  <button 
                    onClick={() => { setSelectedGateway(g); setIsGatewayModalOpen(true); }}
                    className="btn-outline flex-1 py-2 text-xs"
                  >
                    Configure
                  </button>
                  <button 
                    onClick={() => handleDeleteGateway(g.id)}
                    className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-all"
                  >
                    <IconRenderer name="trash" className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
            {filteredGateways.length === 0 && (
              <div className="col-span-full p-10 text-center text-slate-400 italic">No gateways found.</div>
            )}
          </div>
        </div>
      )}

      {tab === 'products' && (
        <div className="space-y-4">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="relative w-full max-w-md">
              <IconRenderer name="magnifying-glass" className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
              <input 
                type="text" 
                placeholder="Search products..." 
                className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
                value={searchProducts}
                onChange={e => setSearchProducts(e.target.value)}
              />
            </div>
            <div className="flex gap-3 flex-wrap">
              <button 
                onClick={() => { setSelectedCategory(null); setIsCategoryModalOpen(true); }}
                className="btn-outline py-3 px-6 text-sm flex items-center justify-center gap-2"
              >
                <IconRenderer name="plus" className="w-4 h-4" />
                Add Category
              </button>
              <button 
                onClick={() => { setSelectedProduct(null); setIsProductModalOpen(true); }}
                className="btn-primary py-3 px-8 text-sm flex items-center justify-center gap-2"
              >
                <IconRenderer name="plus" className="w-4 h-4" />
                Add Product
              </button>
            </div>
          </div>

          {/* Categories Section */}
          {productCategories && productCategories.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-700">Categories ({productCategories.length})</h3>
              <div className="flex gap-3 overflow-x-auto pb-2">
                {productCategories.map(cat => (
                  <div key={cat.id} className="group w-52 shrink-0 rounded-xl border border-slate-200 bg-white p-4 transition-all hover:border-navy">
                    <div className="flex items-start justify-between mb-3">
                      <IconRenderer name={cat.icon || 'layers'} className="w-6 h-6 text-navy" />
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-all">
                        <button
                          onClick={() => { setSelectedCategory(cat); setIsCategoryModalOpen(true); }}
                          className="p-1.5 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition-all"
                          title="Edit"
                        >
                          <IconRenderer name="user-pen" className="w-3 h-3" />
                        </button>
                        <button
                          onClick={() => handleDeleteCategory(cat.id)}
                          className="p-1.5 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-all"
                          title="Delete"
                        >
                          <IconRenderer name="trash" className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                    <p className="text-xs font-bold text-navy mb-1 line-clamp-2">{cat.name}</p>
                    <p className="text-[10px] text-slate-500 line-clamp-1">{cat.description}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {filteredProducts.length === 0 ? (
            <div className="bg-white rounded-3xl shadow-xl p-20 text-center">
              <div className="flex justify-center mb-4">
                <IconRenderer name="shopping-bag" className="w-16 h-16 text-slate-300" />
              </div>
              <h3 className="text-2xl font-bold text-slate-700 mb-2">No Products Yet</h3>
              <p className="text-slate-400 mb-6">Start adding products to your store to get started!</p>
              <button 
                onClick={() => { setSelectedProduct(null); setIsProductModalOpen(true); }}
                className="btn-primary py-3 px-8 flex items-center justify-center gap-2 mx-auto"
              >
                <IconRenderer name="plus" className="w-5 h-5" />
                Add First Product
              </button>
            </div>
          ) : (
            <div className="bg-white rounded-3xl shadow-xl overflow-hidden">
              <div className="overflow-x-auto hidden sm:block">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-navy text-white">
                      <th className="p-6 font-bold">Product</th>
                      <th className="p-6 font-bold">Category</th>
                      <th className="p-6 font-bold">Price</th>
                      <th className="p-6 font-bold">Stock</th>
                      <th className="p-6 font-bold">Rating</th>
                      <th className="p-6 font-bold">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredProducts.map(p => (
                      <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                        <td className="p-6">
                          <div className="flex items-center gap-4">
                            {p.images && p.images[0] && (
                              <img src={p.images[0]} alt={p.name} className="w-12 h-12 rounded-lg object-cover" />
                            )}
                            <div>
                              <div className="font-bold text-navy">{p.name}</div>
                              <div className="text-xs text-slate-400 line-clamp-1">{p.shortDescription}</div>
                            </div>
                          </div>
                        </td>
                        <td className="p-6 font-medium text-slate-600">{p.category}</td>
                        <td className="p-6">
                          <div className="font-bold text-navy">₹{p.discountedPrice || p.price}</div>
                          {p.discountedPrice > 0 && <div className="text-xs text-slate-400 line-through">₹{p.price}</div>}
                        </td>
                        <td className="p-6">
                          <span className={`badge ${p.inStock ? 'bg-green-500' : 'bg-red-500'}`}>
                            {p.inStock ? 'In Stock' : 'Out'}
                          </span>
                        </td>
                        <td className="p-6">
                          <div className="flex items-center gap-1">
                            <IconRenderer name="star" className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                            <span className="font-bold text-navy">{p.ratings.average.toFixed(1)}</span>
                            <span className="text-xs text-slate-400">({p.ratings.count})</span>
                          </div>
                        </td>
                        <td className="p-6">
                          <div className="flex gap-2">
                            <button 
                              onClick={() => { setSelectedProduct(p); setIsProductModalOpen(true); }}
                              className="btn-outline py-2 px-4 text-sm"
                            >
                              Edit
                            </button>
                            <button 
                              onClick={() => handleDeleteProduct(p.id)}
                              className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-all"
                            >
                              <IconRenderer name="trash" className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Mobile View for Products */}
              <div className="sm:hidden divide-y divide-slate-100">
                {filteredProducts.map(p => (
                  <div key={p.id} className="p-6 space-y-4">
                    <div className="flex items-start gap-4">
                      {p.images && p.images[0] && (
                        <img src={p.images[0]} alt={p.name} className="w-16 h-16 rounded-lg object-cover" />
                      )}
                      <div className="flex-1">
                        <div className="font-bold text-navy">{p.name}</div>
                        <div className="text-xs text-slate-400 line-clamp-1 mb-2">{p.category}</div>
                        <div className="flex items-center gap-4">
                          <div>
                            <div className="font-bold text-navy">₹{p.discountedPrice || p.price}</div>
                            {p.discountedPrice > 0 && <div className="text-xs text-slate-400 line-through">₹{p.price}</div>}
                          </div>
                          <span className={`badge text-xs ${p.inStock ? 'bg-green-500' : 'bg-red-500'}`}>
                            {p.inStock ? 'In Stock' : 'Out'}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex justify-between items-center pt-2">
                      <div className="flex items-center gap-1">
                        <IconRenderer name="star" className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                        <span className="font-bold text-navy">{p.ratings.average.toFixed(1)}</span>
                        <span className="text-xs text-slate-400">({p.ratings.count})</span>
                      </div>
                      <div className="flex gap-2">
                        <button 
                          onClick={() => { setSelectedProduct(p); setIsProductModalOpen(true); }}
                          className="btn-outline py-2 px-3 text-xs"
                        >
                          Edit
                        </button>
                        <button 
                          onClick={() => handleDeleteProduct(p.id)}
                          className="p-2 text-red-500 bg-red-50 rounded-lg"
                        >
                          <IconRenderer name="trash" className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {tab === 'documents' && (
        <div className="space-y-4">
          <div className="flex flex-col items-start justify-between gap-4 md:flex-row md:items-center">
            <div className="relative w-full max-w-md"><IconRenderer name="magnifying-glass" className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" /><input type="text" placeholder="Search PDFs..." className="w-full rounded-xl border border-slate-200 py-3 pl-11 pr-4 outline-none transition-all focus:border-primary focus:ring-2 focus:ring-primary/20" value={searchDocuments} onChange={event => setSearchDocuments(event.target.value)} /></div>
            <div className="flex flex-wrap gap-3"><button onClick={() => { setSelectedDocumentCategory(null); setIsDocumentCategoryModalOpen(true); }} className="btn-outline flex items-center justify-center gap-2 px-6 py-3 text-sm"><IconRenderer name="plus" className="h-4 w-4" />Add Category</button><button onClick={() => { setSelectedDocument(null); setIsDocumentModalOpen(true); }} className="btn-primary flex items-center justify-center gap-2 px-8 py-3 text-sm"><IconRenderer name="plus" className="h-4 w-4" />Add PDF</button></div>
          </div>
          {documentCategories.length > 0 ? <div className="flex gap-3 overflow-x-auto pb-2"><>{documentCategories.map(category => <div key={category.id} className="group w-52 shrink-0 rounded-xl border border-slate-200 bg-white p-4 hover:border-navy"><div className="flex items-start justify-between"><IconRenderer name="file-text" className="h-6 w-6 text-navy" /><span className="flex gap-1 opacity-0 transition-all group-hover:opacity-100"><button onClick={() => { setSelectedDocumentCategory(category); setIsDocumentCategoryModalOpen(true); }} className="p-1 text-blue-600"><IconRenderer name="user-pen" className="h-3 w-3" /></button><button onClick={() => handleDeleteDocumentCategory(category.id)} className="p-1 text-red-600"><IconRenderer name="trash" className="h-3 w-3" /></button></span></div><p className="mt-2 line-clamp-2 text-xs font-bold text-navy">{category.name}</p></div>)}</></div> : <div className="rounded-xl border border-dashed border-slate-300 bg-white p-6 text-center text-sm font-semibold text-slate-500">No categories yet</div>}
          {filteredDocuments.length === 0 ? <div className="rounded-3xl bg-white p-20 text-center shadow-xl"><IconRenderer name="file-text" className="mx-auto mb-4 h-16 w-16 text-slate-300" /><h3 className="mb-2 text-2xl font-bold text-slate-700">No PDFs Yet</h3><p className="mb-6 text-slate-400">Add PDFs to make them available on the public Forms & Documents page.</p><button onClick={() => { setSelectedDocument(null); setIsDocumentModalOpen(true); }} className="btn-primary mx-auto flex items-center justify-center gap-2 px-8 py-3"><IconRenderer name="plus" className="h-5 w-5" />Add First PDF</button></div> : <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{filteredDocuments.map(document => <article key={document.id} className={`rounded-2xl border bg-white p-5 shadow-sm ${document.active ? 'border-slate-200' : 'border-slate-200 opacity-60'}`}><div className="flex items-start justify-between gap-3"><IconRenderer name="file-text" className="h-10 w-10 text-primary" /><span className={`badge ${document.active ? 'bg-green-500' : 'bg-slate-400'}`}>{document.active ? 'Active' : 'Hidden'}</span></div><p className="mt-4 text-xs font-bold uppercase tracking-wider text-primary">{document.category}</p><h3 className="mt-1 text-lg font-bold text-navy">{document.name}</h3><p className="mt-2 line-clamp-2 text-sm text-slate-500">{document.description}</p><div className="mt-5 flex items-center gap-2"><button onClick={() => { setSelectedDocument(document); setIsDocumentModalOpen(true); }} className="btn-outline flex-1 px-3 py-2 text-xs">Edit</button><button type="button" onClick={() => { const categorySlug = generateSlug(document.category); const pdfSlug = generateSlug(document.name); const embedUrl = `${window.location.origin}/forms-documents/${categorySlug}/${pdfSlug}?from=%2Fforms-documents&embed=1`; navigator.clipboard.writeText(embedUrl).then(() => { setCopiedDocId(document.id); setTimeout(() => setCopiedDocId(null), 2000); showToast('Embed link copied to clipboard!', 'success'); }).catch(() => { showToast('Failed to copy embed link', 'error'); }); }} title="Copy Embed Link" aria-label="Copy Embed Link" className="rounded-lg p-2 text-blue-600 hover:bg-blue-50 transition-colors"><IconRenderer name={copiedDocId === document.id ? 'check' : 'copy'} className={`h-4 w-4 ${copiedDocId === document.id ? 'text-green-600' : ''}`} /></button><button onClick={() => handleDeleteDocument(document.id)} title="Delete PDF" aria-label="Delete PDF" className="rounded-lg p-2 text-red-500 hover:bg-red-50 transition-colors"><IconRenderer name="trash" className="h-4 w-4" /></button></div></article>)}</div>}
        </div>
      )}

      {tab === 'orders' && (
        <div className="space-y-4">
          <div className="relative max-w-md">
            <IconRenderer name="magnifying-glass" className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search orders (ID, Email)..." 
              className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
              value={searchOrders}
              onChange={e => setSearchOrders(e.target.value)}
            />
          </div>

          {filteredOrders.length === 0 ? (
            <div className="bg-white rounded-3xl shadow-xl p-20 text-center">
              <div className="flex justify-center mb-4">
                <IconRenderer name="package" className="w-16 h-16 text-slate-300" />
              </div>
              <h3 className="text-2xl font-bold text-slate-700 mb-2">No Orders Yet</h3>
              <p className="text-slate-400">Orders will appear here when customers place them in the store.</p>
            </div>
          ) : (
            <div className="bg-white rounded-3xl shadow-xl overflow-hidden">
              <div className="overflow-x-auto hidden sm:block">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-navy text-white">
                      <th className="p-6 font-bold">Order ID</th>
                      <th className="p-6 font-bold">Customer</th>
                      <th className="p-6 font-bold">Items</th>
                      <th className="p-6 font-bold">Total</th>
                      <th className="p-6 font-bold">Status</th>
                      <th className="p-6 font-bold">Payment</th>
                      <th className="p-6 font-bold">Date</th>
                      <th className="p-6 font-bold">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredOrders.map(o => {
                      if (!o || !o.id) return null;
                      const customerName = o.deliveryAddress?.name || 'Unknown';
                      const items = Array.isArray(o.items) ? o.items : [];
                      const total = o.total || 0;
                      const orderStatus = o.orderStatus || 'pending';
                      const paymentStatus = o.paymentStatus || 'pending';
                      const createdAt = o.createdAt ? new Date(o.createdAt).toLocaleDateString('en-IN') : 'N/A';
                      
                      return (
                        <tr 
                          key={o.id} 
                          className="hover:bg-slate-50 transition-colors"
                        >
                          <td className="p-6 font-mono text-sm text-navy font-bold">{o.id}</td>
                          <td className="p-6">
                            <div className="font-bold text-navy">{customerName}</div>
                            <div className="text-xs text-slate-400">{o.email || 'N/A'}</div>
                          </td>
                          <td className="p-6 text-slate-600">{items.length} item{items.length !== 1 ? 's' : ''}</td>
                          <td className="p-6 font-bold text-navy">₹{total}</td>
                          <td className="p-6">
                            <span className={`badge ${
                              orderStatus === 'delivered' ? 'bg-green-500' :
                              orderStatus === 'shipped' ? 'bg-blue-500' :
                              orderStatus === 'processing' ? 'bg-orange-500' :
                              'bg-slate-500'
                            }`}>
                              {orderStatus}
                            </span>
                          </td>
                          <td className="p-6">
                            <span className={`badge ${
                              paymentStatus === 'completed' ? 'bg-green-500' :
                              paymentStatus === 'pending' ? 'bg-yellow-500' :
                              'bg-red-500'
                            }`}>
                              {paymentStatus}
                            </span>
                          </td>
                          <td className="p-6 text-slate-500 text-sm">{createdAt}</td>
                          <td className="p-6">
                            <div className="flex gap-2">
                              <button 
                                onClick={() => {
                                  setSelectedOrder(o);
                                  setIsOrderDetailModalOpen(true);
                                }}
                                className="btn-primary py-2 px-4 text-sm"
                              >
                                View
                              </button>
                              <button 
                                onClick={() => handleDeleteOrder(o.id)}
                                className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-all"
                              >
                                <IconRenderer name="trash" className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Mobile View for Orders */}
              <div className="sm:hidden divide-y divide-slate-100">
                {filteredOrders.map(o => {
                  if (!o || !o.id) return null;
                  const customerName = o.deliveryAddress?.name || 'Unknown';
                  const items = Array.isArray(o.items) ? o.items : [];
                  const total = o.total || 0;
                  const orderStatus = o.orderStatus || 'pending';
                  const paymentStatus = o.paymentStatus || 'pending';
                  const createdAt = o.createdAt ? new Date(o.createdAt).toLocaleDateString('en-IN') : 'N/A';
                  
                  return (
                    <div 
                      key={o.id} 
                      className="p-6 space-y-4"
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="font-mono text-xs text-navy font-bold mb-1">{o.id}</div>
                          <div className="font-bold text-navy">{customerName}</div>
                          <div className="text-xs text-slate-400">{o.email || 'N/A'}</div>
                        </div>
                        <span className={`badge ${
                          orderStatus === 'delivered' ? 'bg-green-500' :
                          orderStatus === 'shipped' ? 'bg-blue-500' :
                          orderStatus === 'processing' ? 'bg-orange-500' :
                          'bg-slate-500'
                        }`}>
                          {orderStatus}
                        </span>
                      </div>
                      <div className="flex justify-between items-center pt-2 border-t border-slate-100">
                        <div>
                          <div className="text-xs text-slate-400 mb-1">{items.length} item{items.length !== 1 ? 's' : ''}</div>
                          <div className="font-bold text-navy">₹{total}</div>
                        </div>
                        <div className="flex gap-2 flex-col items-end">
                          <span className={`badge text-xs ${
                            paymentStatus === 'completed' ? 'bg-green-500' :
                            paymentStatus === 'pending' ? 'bg-yellow-500' :
                            'bg-red-500'
                          }`}>
                            {paymentStatus}
                          </span>
                          <span className="text-xs text-slate-400">{createdAt}</span>
                        </div>
                      </div>
                      <div className="flex gap-2 pt-2">
                        <button 
                          onClick={() => {
                            setSelectedOrder(o);
                            setIsOrderDetailModalOpen(true);
                          }}
                          className="flex-1 btn-primary py-2 text-xs"
                        >
                          View & Manage
                        </button>
                        <button 
                          onClick={() => handleDeleteOrder(o.id)}
                          className="p-2 text-red-500 bg-red-50 rounded-lg"
                        >
                          <IconRenderer name="trash" className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {isProductModalOpen && productCategories && (
        <ProductModal 
          product={selectedProduct || undefined}
          categories={productCategories}
          onClose={() => { setIsProductModalOpen(false); setSelectedProduct(null); }}
          onSave={async (productData) => {
            // Check if product exists by checking if selectedProduct was provided
            const existingProductIndex = products.findIndex(p => p.id === productData.id);
            
            if (existingProductIndex !== -1 && selectedProduct) {
              // Update existing product
              if (onEditProduct) {
                // Remove id from update data and pass id separately
                const { id, ...dataToUpdate } = productData;
                await onEditProduct(id, dataToUpdate);
              }
            } else {
              // Add new product
              if (onEditProduct) {
                await onEditProduct(productData.id, productData);
              }
            }
          }}
        />
      )}

      {isCategoryModalOpen && (
        <CategoryModal 
          category={selectedCategory || undefined}
          onClose={() => { setIsCategoryModalOpen(false); setSelectedCategory(null); }}
          onSave={async (categoryData) => {
            try {
              const existingCategory = productCategories.find(c => c.id === categoryData.id);
              
              if (existingCategory && selectedCategory) {
                // Update existing category
                if (onUpdateCategory) {
                  const { id, ...dataToUpdate } = categoryData;
                  await onUpdateCategory(id, dataToUpdate);
                  showToast('Category updated successfully!', 'success');
                }
              } else {
                // Add new category
                if (onAddCategory) {
                  await onAddCategory(categoryData);
                  showToast('Category added successfully!', 'success');
                }
              }
            } catch (error: any) {
              showToast(error, 'error', 'Failed to save category');
            }
          }}
        />
      )}

      {isDocumentModalOpen && (
        <DocumentModal
          document={selectedDocument}
          categories={documentCategories}
          onClose={() => { setIsDocumentModalOpen(false); setSelectedDocument(null); }}
          onSave={async (data, id) => { await onSaveDocument?.(data, id); }}
        />
      )}

      {isDocumentCategoryModalOpen && (
        <DocumentCategoryModal
          category={selectedDocumentCategory}
          onClose={() => { setIsDocumentCategoryModalOpen(false); setSelectedDocumentCategory(null); }}
          onSave={async category => { await onSaveDocumentCategory?.(category, selectedDocumentCategory?.id); }}
        />
      )}

      {isGatewayModalOpen && (
        <GatewayModal 
          gateway={selectedGateway}
          onClose={() => { setIsGatewayModalOpen(false); setSelectedGateway(null); }}
          onSave={handleSaveGateway}
        />
      )}

      {isOrderDetailModalOpen && selectedOrder && (
        <OrderManageModal 
          order={selectedOrder}
          onClose={() => { setIsOrderDetailModalOpen(false); setSelectedOrder(null); }}
          currentUser={currentUser}
          onUpdateOrder={onUpdateOrder}
          onDeleteOrder={onDeleteOrder}
        />
      )}

      {tab === 'reviews' && (
        <div className="space-y-4">
          <div className="relative max-w-md">
            <IconRenderer name="magnifying-glass" className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search reviews (Product, User)..." 
              className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all"
              value={searchReviews}
              onChange={e => setSearchReviews(e.target.value)}
            />
          </div>

          {(productReviews || []).length === 0 ? (
            <div className="bg-white rounded-3xl shadow-xl p-20 text-center">
              <div className="flex justify-center mb-4">
                <IconRenderer name="star" className="w-16 h-16 text-slate-300" />
              </div>
              <h3 className="text-2xl font-bold text-slate-700 mb-2">No Reviews Yet</h3>
              <p className="text-slate-400">Customer reviews will appear here.</p>
            </div>
          ) : (
            <div className="bg-white rounded-3xl shadow-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-navy text-white">
                      <th className="p-4 sm:p-6 font-bold text-sm">Product</th>
                      <th className="p-4 sm:p-6 font-bold text-sm">User</th>
                      <th className="p-4 sm:p-6 font-bold text-sm">Rating</th>
                      <th className="p-4 sm:p-6 font-bold text-sm">Images</th>
                      <th className="p-4 sm:p-6 font-bold text-sm">Date</th>
                      <th className="p-4 sm:p-6 font-bold text-sm">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {(productReviews || []).filter((r: ProductReview) => 
                      (r.productId?.toLowerCase().includes(searchReviews.toLowerCase()) ||
                       r.userName?.toLowerCase().includes(searchReviews.toLowerCase()) ||
                       r.text?.toLowerCase().includes(searchReviews.toLowerCase()))
                    ).map(review => (
                      <tr key={review.id} className="hover:bg-slate-50 transition-colors">
                        <td className="p-4 sm:p-6 font-medium text-slate-600 text-sm">{review.productId || 'N/A'}</td>
                        <td className="p-4 sm:p-6">
                          <div className="font-bold text-navy text-sm">{review.userName}</div>
                          <div className="text-xs text-slate-400">{review.uid}</div>
                        </td>
                        <td className="p-4 sm:p-6">
                          <div className="flex gap-0.5">
                            {[...Array(5)].map((_, i) => (
                              <span key={i} className="text-yellow-400 text-sm">
                                {i < review.rating ? '★' : '☆'}
                              </span>
                            ))}
                          </div>
                          <div className="text-xs text-slate-500 mt-1">{review.rating}/5</div>
                        </td>
                        <td className="p-4 sm:p-6 text-sm">
                          {review.images && review.images.length > 0 ? (
                            <span className="badge bg-blue-500">{review.images.length} images</span>
                          ) : (
                            <span className="text-slate-400 text-xs">No images</span>
                          )}
                        </td>
                        <td className="p-4 sm:p-6 text-xs sm:text-sm text-slate-500">
                          {new Date(review.date).toLocaleDateString('en-IN')}
                        </td>
                        <td className="p-4 sm:p-6">
                          <div className="flex gap-2">
                            <button 
                              onClick={() => {
                                setSelectedReview(review);
                                setIsReviewModalOpen(true);
                              }}
                              className="btn-primary py-2 px-3 text-xs"
                            >
                              View
                            </button>
                            <button 
                              onClick={() => handleDeleteReview(review.id)}
                              className="btn-danger py-2 px-3 text-xs bg-red-500 hover:bg-red-600 text-white rounded-lg"
                            >
                              Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {isExportModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[2000] flex items-center justify-center p-2 sm:p-4">
          <div className="bg-white rounded-2xl sm:rounded-3xl w-full max-w-lg relative overflow-hidden shadow-2xl flex flex-col max-h-[98vh] sm:max-h-[95vh]">
            <div className="p-4 sm:p-6 bg-white border-b border-slate-100 flex justify-between items-center">
              <h3 className="text-xl sm:text-2xl font-bold text-navy">Export Data</h3>
              <button
                onClick={() => setIsExportModalOpen(false)}
                className="p-1.5 sm:p-2 hover:bg-slate-100 rounded-full transition-all"
                aria-label="Close export dialog"
              >
                <IconRenderer name="x" className="w-5 h-5 sm:w-6 sm:h-6 text-slate-400" />
              </button>
            </div>

            <div className="p-4 sm:p-6 space-y-4 sm:space-y-6">
              <div>
                <label htmlFor="export-format" className="block text-sm font-bold text-navy mb-2">File format</label>
                <SelectDropdown
                  value={exportFormat}
                  onChange={value => setExportFormat(value as 'excel' | 'json')}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all bg-white font-medium text-navy text-sm"
                  options={[
                    { value: 'excel', label: 'Excel (.xlsx)' },
                    { value: 'json', label: 'JSON (.json)' },
                  ]}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  onClick={() => { exportToExcel('all'); setIsExportModalOpen(false); }}
                  className="bg-navy text-white px-4 py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-navy-light transition-all shadow-lg"
                >
                  <IconRenderer name="file-export" className="w-5 h-5" />
                  Export All Data
                </button>
                <button
                  onClick={() => {
                    if (tab === 'privacy') {
                      exportPrivacyRequests();
                    } else {
                      exportToExcel(tab);
                    }
                    setIsExportModalOpen(false);
                  }}
                  className="bg-green-600 text-white px-4 py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-green-700 transition-all shadow-lg shadow-green-600/20"
                >
                  <IconRenderer name="excel" className="w-5 h-5" />
                  Export {tab.charAt(0).toUpperCase() + tab.slice(1)}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {tab === 'privacy' && (
        <div className="space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm space-y-1">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Inquiries</span>
              <p className="text-2xl sm:text-3xl font-extrabold text-navy">{privacyRequests.length}</p>
            </div>
            <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm space-y-1">
              <span className="text-xs font-semibold text-amber-600 uppercase tracking-wider">New / Submitted</span>
              <p className="text-2xl sm:text-3xl font-extrabold text-amber-600">
                {privacyRequests.filter(r => r.status === 'submitted').length}
              </p>
            </div>
            <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm space-y-1">
              <span className="text-xs font-semibold text-blue-600 uppercase tracking-wider">Under Investigation</span>
              <p className="text-2xl sm:text-3xl font-extrabold text-blue-600">
                {privacyRequests.filter(r => r.status === 'in_review').length}
              </p>
            </div>
            <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm space-y-1">
              <span className="text-xs font-semibold text-emerald-600 uppercase tracking-wider">Resolved</span>
              <p className="text-2xl sm:text-3xl font-extrabold text-emerald-600">
                {privacyRequests.filter(r => r.status === 'resolved').length}
              </p>
            </div>
          </div>

          {/* Search & Action Bar */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            <div className="flex flex-1 items-center gap-3">
              <div className="relative flex-1 max-w-md">
                <IconRenderer name="magnifying-glass" className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search Ticket, Name, Email, Reference..."
                  className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-200 focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all text-xs sm:text-sm"
                  value={searchPrivacy}
                  onChange={e => setSearchPrivacy(e.target.value)}
                />
              </div>

              <select
                value={privacyStatusFilter}
                onChange={e => setPrivacyStatusFilter(e.target.value as any)}
                className="px-4 py-3 rounded-xl border border-slate-200 bg-white text-xs sm:text-sm font-semibold text-slate-700 outline-none"
              >
                <option value="all">All Statuses</option>
                <option value="submitted">Submitted</option>
                <option value="in_review">In Review</option>
                <option value="additional_info_required">Info Required</option>
                <option value="resolved">Resolved</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={exportPrivacyRequests}
                className="px-4 py-3 rounded-xl bg-slate-100 text-slate-700 hover:bg-slate-200 transition font-bold text-xs sm:text-sm flex items-center gap-2"
              >
                <IconRenderer name="file-export" className="w-4 h-4" />
                Export Audit Log
              </button>
              <button
                type="button"
                onClick={() => navigate('/privacy-request')}
                className="px-4 py-3 rounded-xl bg-primary/10 text-primary hover:bg-primary/20 transition font-bold text-xs sm:text-sm flex items-center gap-2"
              >
                <IconRenderer name="shield-check" className="w-4 h-4" />
                Public Form
              </button>
            </div>
          </div>

          {/* Table Container */}
          <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100">
            {privacyLoading ? (
              <div className="p-12 text-center text-slate-400">Loading privacy and grievance records...</div>
            ) : filteredPrivacyRequests.length === 0 ? (
              <div className="p-12 text-center space-y-2">
                <IconRenderer name="shield-check" className="h-10 w-10 text-slate-300 mx-auto" />
                <h4 className="font-bold text-navy">No Privacy Requests Found</h4>
                <p className="text-xs text-slate-500">
                  {searchPrivacy || privacyStatusFilter !== 'all'
                    ? 'Try clearing your search or status filter.'
                    : 'Submissions from the public privacy & grievance form will appear here.'}
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-navy text-white text-xs sm:text-sm">
                      <th className="p-4 sm:p-5 font-bold">Ticket ID</th>
                      <th className="p-4 sm:p-5 font-bold">Date Logged</th>
                      <th className="p-4 sm:p-5 font-bold">Category</th>
                      <th className="p-4 sm:p-5 font-bold">Requester</th>
                      <th className="p-4 sm:p-5 font-bold">Status</th>
                      <th className="p-4 sm:p-5 font-bold text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs sm:text-sm">
                    {filteredPrivacyRequests.map(item => (
                      <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="p-4 sm:p-5 font-mono font-bold text-primary">
                          {item.id}
                        </td>
                        <td className="p-4 sm:p-5 text-slate-500 whitespace-nowrap">
                          {new Date(item.createdAt).toLocaleDateString('en-IN', {
                            day: '2-digit',
                            month: 'short',
                            year: 'numeric'
                          })}
                        </td>
                        <td className="p-4 sm:p-5 font-medium text-slate-700 capitalize">
                          {PRIVACY_REQUEST_CATEGORIES.find(c => c.value === item.category)?.label || item.category}
                        </td>
                        <td className="p-4 sm:p-5">
                          <div className="font-bold text-navy">{item.name}</div>
                          <div className="text-xs text-slate-400">{item.email}</div>
                          {item.phone && <div className="text-[11px] text-slate-400">{item.phone}</div>}
                        </td>
                        <td className="p-4 sm:p-5">
                          <span
                            className={`px-3 py-1 rounded-full text-xs font-bold capitalize whitespace-nowrap ${
                              item.status === 'resolved'
                                ? 'bg-emerald-100 text-emerald-800'
                                : item.status === 'rejected'
                                ? 'bg-red-100 text-red-800'
                                : item.status === 'in_review'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {item.status.replace('_', ' ')}
                          </span>
                        </td>
                        <td className="p-4 sm:p-5 text-right">
                          <button
                            type="button"
                            onClick={() => handleOpenPrivacyModal(item)}
                            className="px-3 py-1.5 rounded-lg bg-navy text-white hover:bg-navy-light text-xs font-semibold transition"
                          >
                            Manage
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Privacy Request Manage Modal */}
      {isPrivacyModalOpen && selectedPrivacyReq && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[2000] flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-2xl sm:rounded-3xl shadow-2xl w-full max-w-2xl max-h-[92vh] overflow-hidden flex flex-col">
            {/* Header */}
            <div className="p-5 sm:p-6 border-b border-slate-100 flex items-start justify-between flex-shrink-0">
              <div>
                <span className="text-xs font-mono font-bold text-primary">{selectedPrivacyReq.id}</span>
                <h3 className="text-xl font-bold text-navy mt-1">
                  {PRIVACY_REQUEST_CATEGORIES.find(c => c.value === selectedPrivacyReq.category)?.label || selectedPrivacyReq.category}
                </h3>
                <p className="text-xs text-slate-500">
                  Logged on {new Date(selectedPrivacyReq.createdAt).toLocaleString('en-IN')}
                </p>
              </div>
              <button
                type="button"
                onClick={() => { setIsPrivacyModalOpen(false); setSelectedPrivacyReq(null); }}
                className="p-2 hover:bg-slate-100 rounded-full transition text-slate-400 hover:text-slate-600"
              >
                <IconRenderer name="x" className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5 text-xs sm:text-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div>
                  <span className="font-bold text-slate-400 uppercase text-[11px] block">Requester Name</span>
                  <span className="font-semibold text-navy text-sm">{selectedPrivacyReq.name}</span>
                </div>
                <div>
                  <span className="font-bold text-slate-400 uppercase text-[11px] block">Email</span>
                  <a href={`mailto:${selectedPrivacyReq.email}`} className="text-primary font-medium hover:underline">
                    {selectedPrivacyReq.email}
                  </a>
                </div>
                {selectedPrivacyReq.phone && (
                  <div>
                    <span className="font-bold text-slate-400 uppercase text-[11px] block">Phone</span>
                    <span>{selectedPrivacyReq.phone}</span>
                  </div>
                )}
                {selectedPrivacyReq.referenceId && (
                  <div>
                    <span className="font-bold text-slate-400 uppercase text-[11px] block">Reference ID</span>
                    <span className="font-mono">{selectedPrivacyReq.referenceId}</span>
                  </div>
                )}
              </div>

              <div>
                <span className="font-bold text-slate-700 block mb-1 uppercase tracking-wider text-xs">
                  User Submitted Description:
                </span>
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 text-slate-700 whitespace-pre-line leading-relaxed">
                  {selectedPrivacyReq.description}
                </div>
              </div>

              <div className="space-y-2">
                <label className="font-bold text-slate-700 block uppercase tracking-wider text-xs">
                  Official Grievance Redressal / Communication Note:
                </label>
                <textarea
                  rows={4}
                  value={adminNoteText}
                  onChange={e => setAdminNoteText(e.target.value)}
                  placeholder="Record investigation findings, steps taken, or communication sent to the applicant..."
                  className="input-field p-3 text-xs sm:text-sm leading-relaxed"
                />
              </div>

              <div className="space-y-2">
                <span className="font-bold text-slate-700 block uppercase tracking-wider text-xs">
                  Update Request Status:
                </span>
                <div className="flex flex-wrap gap-2">
                  {(['submitted', 'in_review', 'additional_info_required', 'resolved', 'rejected'] as PrivacyRequestStatus[]).map(statusKey => (
                    <button
                      key={statusKey}
                      type="button"
                      disabled={updatingPrivacy}
                      onClick={() => handleSavePrivacyStatus(statusKey)}
                      className={`px-3.5 py-2 rounded-xl text-xs font-bold capitalize transition border ${
                        selectedPrivacyReq.status === statusKey
                          ? 'bg-navy text-white border-navy shadow-sm'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      {statusKey.replace(/_/g, ' ')}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
              <a
                href={`mailto:${selectedPrivacyReq.email}?subject=[${selectedPrivacyReq.id}] Privacy Request Update - India Cyber Cafe`}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-primary hover:underline"
              >
                <IconRenderer name="envelope" className="w-4 h-4" />
                Email Applicant Directly
              </a>
              <button
                type="button"
                onClick={() => { setIsPrivacyModalOpen(false); setSelectedPrivacyReq(null); }}
                className="px-5 py-2 rounded-xl bg-slate-200 text-slate-700 font-semibold text-xs hover:bg-slate-300 transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      <ConfirmationModal 
        isOpen={confirmConfig.isOpen}
        onClose={() => setConfirmConfig(prev => ({ ...prev, isOpen: false }))}
        onConfirm={confirmConfig.onConfirm}
        title={confirmConfig.title}
        message={confirmConfig.message}
        type={confirmConfig.type}
      />

      {/* Review Details Modal */}
      {isReviewModalOpen && selectedReview && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[2000] flex items-center justify-center p-2 sm:p-4">
          <div className="bg-white rounded-xl sm:rounded-3xl shadow-2xl w-full max-w-2xl max-h-[92vh] overflow-hidden flex flex-col">
            {/* Header */}
            <div className="p-4 sm:p-6 bg-white border-b border-slate-100 flex items-start justify-between flex-shrink-0">
              <div className="flex-1">
                <h2 className="text-xl sm:text-2xl font-bold text-navy mb-2">Customer Review</h2>
                <div className="flex items-center gap-2 flex-wrap">
                  <div className="flex gap-0.5 text-yellow-500">
                    {[...Array(5)].map((_, i) => (
                      <span key={i} className="text-lg sm:text-xl">
                        {i < selectedReview.rating ? '★' : '☆'}
                      </span>
                    ))}
                  </div>
                  <span className="font-bold text-navy bg-white/80 px-2.5 py-0.5 rounded-lg text-sm sm:text-base">{selectedReview.rating}/5</span>
                </div>
              </div>
              <button 
                onClick={() => { setIsReviewModalOpen(false); setSelectedReview(null); }}
                className="p-1.5 sm:p-2 hover:bg-slate-100 rounded-full transition-all flex-shrink-0"
              >
                <IconRenderer name="x" className="w-5 h-5 sm:w-6 sm:h-6 text-slate-400" />
              </button>
            </div>

            {/* Content - Scrollable */}
            <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-4 sm:py-5 space-y-4 sm:space-y-5">
              {/* User Info */}
              <div className="bg-slate-50 p-3 sm:p-4 rounded-lg sm:rounded-xl border border-slate-200">
                <p className="text-xs text-slate-500 uppercase font-bold tracking-widest mb-2">Reviewed By</p>
                <h3 className="text-base sm:text-lg font-bold text-navy mb-1">{selectedReview.userName}</h3>
                <div className="space-y-0.5 text-xs sm:text-sm text-slate-600">
                  <p><span className="font-semibold">Email:</span> {selectedReview.userEmail || selectedReview.uid}</p>
                  <p><span className="font-semibold">Date:</span> {new Date(selectedReview.date).toLocaleDateString('en-IN')}</p>
                  <p><span className="font-semibold">Product:</span> {selectedReview.productId}</p>
                </div>
              </div>

              {/* Review Text */}
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-slate-700 mb-2 uppercase tracking-widest">Review</h4>
                <div className="bg-blue-50 border-l-4 border-blue-500 p-3 sm:p-4 rounded-lg">
                  <p className="text-slate-700 text-sm leading-relaxed whitespace-pre-wrap break-words">
                    {selectedReview.text}
                  </p>
                </div>
              </div>

              {/* Images */}
              {selectedReview.images && selectedReview.images.length > 0 && (
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-slate-700 mb-2 uppercase tracking-widest">
                    Images ({selectedReview.images.length})
                  </h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 sm:gap-3">
                    {selectedReview.images.map((img, idx) => (
                      <div key={idx} className="group cursor-pointer">
                        <img 
                          src={img} 
                          alt={`Review image ${idx + 1}`}
                          className="w-full h-24 sm:h-32 object-cover rounded-lg shadow-md group-hover:shadow-lg transition-all group-hover:scale-105"
                          onClick={() => window.open(img, '_blank')}
                          title="Click to view full size"
                        />
                        <p className="text-xs text-slate-500 mt-1 text-center">Img {idx + 1}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Stats */}
              <div className="grid grid-cols-2 gap-2 sm:gap-3 bg-slate-50 p-3 sm:p-4 rounded-lg sm:rounded-xl border border-slate-200">
                <div>
                  <p className="text-xs text-slate-500 uppercase font-bold mb-1">Helpfulness</p>
                  <p className="text-lg sm:text-xl font-bold text-navy">👍 {selectedReview.helpful || 0}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-500 uppercase font-bold mb-1">Posted</p>
                  <p className="text-sm text-slate-700">{new Date(selectedReview.date).toLocaleDateString('en-IN')}</p>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="bg-slate-50 border-t border-slate-200 p-3 sm:p-4 flex gap-2 flex-shrink-0">
              <button 
                onClick={async () => {
                  if (selectedReview) {
                    const currentHelpful = selectedReview.helpful || 0;
                    await onUpdateProductReview?.(selectedReview.id, { 
                      helpful: currentHelpful + 1,
                      helpfulBy: [...(selectedReview.helpfulBy || []), currentUser?.uid || 'admin']
                    });
                    setSelectedReview({ ...selectedReview, helpful: currentHelpful + 1 });
                    showToast('Marked as helpful!', 'success');
                  }
                }}
                className="flex-1 btn-outline py-2 sm:py-3 text-xs sm:text-sm flex items-center justify-center gap-1.5 sm:gap-2 hover:bg-blue-100"
              >
                <span>👍</span>
                <span className="hidden sm:inline">Mark Helpful</span>
                <span className="sm:hidden">Helpful</span>
              </button>
              <button 
                onClick={() => {
                  if (selectedReview.images && selectedReview.images.length > 0) {
                    window.open(selectedReview.images[0], '_blank');
                  }
                }}
                disabled={!selectedReview.images || selectedReview.images.length === 0}
                className="flex-1 btn-outline py-2 sm:py-3 text-xs sm:text-sm flex items-center justify-center gap-1.5 sm:gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <IconRenderer name="image" className="w-4 h-4" />
                <span className="hidden sm:inline">View Images</span>
                <span className="sm:hidden">Images</span>
              </button>
              <button 
                onClick={() => { setIsReviewModalOpen(false); setSelectedReview(null); }}
                className="flex-1 btn-primary py-2 sm:py-3 text-xs sm:text-sm"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
